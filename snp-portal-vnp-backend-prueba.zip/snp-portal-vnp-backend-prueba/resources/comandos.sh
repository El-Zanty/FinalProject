#INI AMBIENTE DE DEV

#Crear BuildConfig en Openshift de tipo Pipeline
oc project jenkins
oc create -f BuildConfig.yaml

#Adicionar permisos al service-account del namespace de Jenkins
oc policy add-role-to-user edit system:serviceaccount:jenkins:jenkins -n migracion-pasarelas-dev

#Crear BuildConfig de tipo binario y referenciando la imagen bade de Java
oc new-build --binary=true --name="portal-backend-cicd" openshift/openjdk18-openshift:latest -n migracion-pasarelas-dev

#Crear el DeploymentConfig
oc new-app operacionesqr-dev/qr-purchase-dev:latest --name=qr-purchase-dev --allow-missing-imagestream-tags=true -n operacionesqr-dev

#Desactivar triggers en la app para evitar el build y el deploy  automático (Se quiere que el proceso lo controle jenkins)
oc set triggers dc/portal-backend --remove-all -n migracion-pasarelas-dev

#Crear el service a partir del deploymentConfig, en este caso el puerto 8080
oc expose dc qr-api-transactionstatus --port 8080 -n qr-api-transactionstatus

#Crear el route a partir del servicio
oc create route edge --service=qr-api-transactionstatus -n qr-api-transactionstatus

#Montaje de configmaps y secrets
oc set volume dc/qr-api-transactionstatus --add --name=spring-conf --mount-path=/deployments/config --configmap-name=spring-conf -n qr-api-transactionstatus

oc set volume dc/qr-api-transactionstatus --add --name=properties --mount-path=/properties --configmap-name=properties -n qr-api-transactionstatus

oc set volume dc/qr-api-transactionstatus --add --name=aggregator-secret --mount-path=/propiedades/secrets --secret-name=aggregator-secret -n qr-api-transactionstatus
#FIN AMBIENTE DE DEV


#INI AMBIENTE DE QA

#Asinar permisos para que el namespace de qa vea imágenes del name space de dev
oc policy add-role-to-user system:image-puller system:serviceaccount:qr-api-transactionstatus-qa:default  -n qr-api-transactionstatus

#Adicionar permisos al service-account del namespace de Jenkins
oc policy add-role-to-user edit system:serviceaccount:jenkins:jenkins -n qr-api-transactionstatus-qa

#Crear el DeploymentConfig
oc new-app qr-api-transactionstatus/qr-api-transactionstatus:latest --name=qr-api-transactionstatus --allow-missing-imagestream-tags=true -n qr-api-transactionstatus-qa

#Desactivar triggers en la app para evitar el build y el deploy  automático (Se quiere que el proceso lo controle jenkins)
oc set triggers dc/qr-api-transactionstatus --remove-all -n qr-api-transactionstatus-qa

#Crear el service a partir del deploymentConfig, en este caso el puerto 8080
oc expose dc qr-api-transactionstatus --port 8080 -n qr-api-transactionstatus-qa

#Crear el route a partir del servicio
oc create route edge --service=qr-api-transactionstatus -n qr-api-transactionstatus-qa

#Montaje de configmaps y secrets
oc set volume dc/qr-api-transactionstatus --add --name=spring-conf --mount-path=/deployments/config --configmap-name=spring-conf -n qr-api-transactionstatus-qa

oc set volume dc/qr-api-transactionstatus --add --name=properties --mount-path=/properties --configmap-name=properties -n qr-api-transactionstatus-qa

oc set volume dc/qr-api-transactionstatus --add --name=secret --mount-path=/propiedades/secrets --secret-name=secret -n qr-api-transactionstatus-qa
#FIN AMBIENTE DE QA