package com.credibanco.migracion.portal.backend.controllers;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;

import java.util.ArrayList;
import java.util.List;

import com.credibanco.migracion.portal.backend.services.IOrquestadorPasarelasService;
import com.credibanco.migracion.portal.backend.services.OrquestadorPasarelasService;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import com.credibanco.migracion.portal.backend.models.dto.CrearTerminalRequestDto;
import com.credibanco.migracion.portal.backend.models.dto.CrearTerminalResponseDto;
import com.credibanco.migracion.portal.backend.models.dto.DireccionInstalacion;
import com.credibanco.migracion.portal.backend.models.dto.SolicitudTerminales;
import com.credibanco.migracion.portal.backend.services.ITerminalesService;
import com.credibanco.migracion.portal.backend.services.TerminalesService;

public class TerminalesControllerTest {
	
	@Autowired
	ITerminalesService terminalesService = Mockito.mock(TerminalesService.class);

	@Autowired
	IOrquestadorPasarelasService orquestadorPasarelasService = Mockito.mock(OrquestadorPasarelasService.class);
	
	@Autowired
	TerminalesController terminalesController = new TerminalesController(terminalesService, orquestadorPasarelasService);

	@Test
	public void debeResponder200ExitosoCuandoSoliciteCrearTerminalNuevo() throws Exception {
		//Definicion entradas salidas
		DireccionInstalacion requestDireccion = new DireccionInstalacion();
		requestDireccion.setCodigoRegion("11001"); //Codigo DANE Bogota
		requestDireccion.setDireccionNumero("Calle 70 #7-30");
		requestDireccion.setLatitud("0");
		requestDireccion.setLongitud("0");
		requestDireccion.setPais("170");//Colombia
		
		List<String> servicios = new ArrayList<>();
		servicios.add("50170015");
		
		
		SolicitudTerminales requestTerminal = new SolicitudTerminales();
		requestTerminal.setCodigoArrendamiento("50040009");
		requestTerminal.setDireccionDeInstalacion(requestDireccion);
		requestTerminal.setDueno("50145001");
		requestTerminal.setEstadoTerminal("TRMS0001");
		requestTerminal.setFechaRetiroProgramado("");
		requestTerminal.setIndicadorIac("50115001");
		requestTerminal.setIndicadorIva("50115003");
		requestTerminal.setIndicadorPropina(0);
		requestTerminal.setMarcaDispositivo(""); //Catalogo de marcar desde archivo Excel
		requestTerminal.setNumeroCaja("");
		requestTerminal.setObservaciones("");
		requestTerminal.setSello("");
		requestTerminal.setSerial("");
		requestTerminal.setIdServicio(servicios);
		requestTerminal.setTipoComunicacion("50125009");
		requestTerminal.setTipoDispositivo("TRMT0004");
		requestTerminal.setTipoIntegracionTEF("50105000");
		
		CrearTerminalRequestDto request = new CrearTerminalRequestDto();
		request.setCodigoComercio("055051304");
		request.setCodigoOriginador("3");
		request.setTerminal(requestTerminal);
		
		CrearTerminalResponseDto resultMock = new CrearTerminalResponseDto();
		resultMock.setCodigoRespuesta("00");
		resultMock.setMensaje("Exitoso");
		
		//Mock
		Mockito.when(terminalesService.crearTerminal(any())).thenReturn(resultMock);
		
		//Act
		ResponseEntity<?> response = terminalesController.crearTerminal(null, request, null);
		CrearTerminalResponseDto result =(CrearTerminalResponseDto) response.getBody();
		
		assertEquals(201, response.getStatusCodeValue());
		assertEquals("00", result.getCodigoRespuesta());
	}

}
