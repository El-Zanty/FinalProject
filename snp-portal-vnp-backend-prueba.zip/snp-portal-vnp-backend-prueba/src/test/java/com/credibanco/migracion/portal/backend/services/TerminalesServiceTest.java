package com.credibanco.migracion.portal.backend.services;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import com.credibanco.migracion.portal.backend.clients.SVConsultaComerciosTerminales;
import com.credibanco.migracion.portal.backend.clients.SVTerminalGenericaClient;
import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.CrearTerminalRequestDto;
import com.credibanco.migracion.portal.backend.models.dto.CrearTerminalResponseDto;
import com.credibanco.migracion.portal.backend.models.dto.DireccionInstalacion;
import com.credibanco.migracion.portal.backend.models.dto.SolicitudTerminales;
import com.credibanco.migracion.portal.backend.models.dto.TerminalGenericaResponseDto;

public class TerminalesServiceTest {
	
	@Autowired
	private SVTerminalGenericaClient svTerminalGenericaClientMock = Mockito.mock(SVTerminalGenericaClient.class);
	
	@Autowired
	private SVConsultaComerciosTerminales svConsultaComerciosTerminales = Mockito.mock(SVConsultaComerciosTerminales.class);
	
	@Autowired
	TerminalesService terminalService = new TerminalesService(svTerminalGenericaClientMock, svConsultaComerciosTerminales);
	
	@Test
	public void debeResponderExitosoCuandoSeCreaTerminalNueva() throws PortalBackendException {
		//Definicion entradas salidas
		DireccionInstalacion requestDireccion = new DireccionInstalacion();
		requestDireccion.setCodigoRegion("11001"); //Codigo DANE Bogota
		requestDireccion.setDireccionNumero("Calle 70 #7-30");
		requestDireccion.setLatitud("0");
		requestDireccion.setLongitud("0");
		requestDireccion.setPais("170");//Colombia
		
		List<String> servicios = new ArrayList<>();
		servicios.add("50170015");
		
		
		SolicitudTerminales requestTerminal = new SolicitudTerminales();
		requestTerminal.setCodigoArrendamiento("50040009");
		requestTerminal.setDireccionDeInstalacion(requestDireccion);
		requestTerminal.setDueno("50145001");
		requestTerminal.setEstadoTerminal("TRMS0001");
		requestTerminal.setFechaRetiroProgramado("");
		requestTerminal.setIndicadorIac("50115001");
		requestTerminal.setIndicadorIva("50115003");
		requestTerminal.setIndicadorPropina(0);
		requestTerminal.setMarcaDispositivo(""); //Catalogo de marcar desde archivo Excel
		requestTerminal.setNumeroCaja("");
		requestTerminal.setObservaciones("");
		requestTerminal.setSello("");
		requestTerminal.setSerial("");
		requestTerminal.setIdServicio(servicios);
		requestTerminal.setTipoComunicacion("50125009");
		requestTerminal.setTipoDispositivo("TRMT0004");
		requestTerminal.setTipoIntegracionTEF("50105000");
		
		CrearTerminalRequestDto request = new CrearTerminalRequestDto();
		request.setCodigoComercio("055051304");
		request.setCodigoOriginador("3");
		request.setTerminal(requestTerminal);
		
		//TerminalGenericaObjectDto terminalResultMock = new TerminalGenericaObjectDto();
		
		
		TerminalGenericaResponseDto resultMock = new TerminalGenericaResponseDto();
		resultMock.setCode("00");
		resultMock.setMessage("Exitoso");
		resultMock.setObject(null);
		
		//Mock
		Mockito.when(svTerminalGenericaClientMock.postTerminalGenerica(any())).thenReturn(resultMock);
		
		//Act
		CrearTerminalResponseDto response = terminalService.crearTerminal(request);
		
		//Validar
		assertEquals("00",response.getCodigoRespuesta());
		assertEquals("Exitoso",response.getMensaje());
		
	}

}
