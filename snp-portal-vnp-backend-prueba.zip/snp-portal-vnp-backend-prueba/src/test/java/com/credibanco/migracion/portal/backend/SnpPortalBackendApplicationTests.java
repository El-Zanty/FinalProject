package com.credibanco.migracion.portal.backend;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnpPortalBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
