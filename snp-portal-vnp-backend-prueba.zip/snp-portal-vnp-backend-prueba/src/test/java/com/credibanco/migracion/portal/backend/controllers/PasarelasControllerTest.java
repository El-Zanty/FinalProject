package com.credibanco.migracion.portal.backend.controllers;

public class PasarelasControllerTest {

}
