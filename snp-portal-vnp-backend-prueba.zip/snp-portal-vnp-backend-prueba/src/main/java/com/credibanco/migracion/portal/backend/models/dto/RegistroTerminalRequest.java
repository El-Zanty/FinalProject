package com.credibanco.migracion.portal.backend.models.dto;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;

public class RegistroTerminalRequest {
	
	@CsvBindByPosition(position = 5)
	@CsvBindByName(column = "ESTADO_TERMINAL")
	private Boolean activo;
	
	@CsvBindByPosition(position = 0)
	@CsvBindByName(column = "NIT_COMERCIO")
	private String nitComercio;
	
	@CsvBindByPosition(position = 1)
	@CsvBindByName(column = "CODIGO_UNICO")
	private String cuComercio;
	
	@CsvBindByPosition(position = 2)
	@CsvBindByName(column = "NOMBRE_DEL_COMERCIO")
	private String nombreComercio;
	
	@CsvBindByPosition(position = 3)
	@CsvBindByName(column = "NUMERO_TERMINAL")
	private String numeroTerminal;
	
	@CsvBindByPosition(position = 4)
	@CsvBindByName(column = "NOMBRE_PASARELA")
	private String nombrePasarela;
	
	private String usuarioCreacion;
	
	private String usuarioModificacion;
	
	public Boolean getActivo() {
		return activo;
	}
	public void setActivo(Boolean activo) {
		this.activo = activo;
	}
	public String getNitComercio() {
		return nitComercio;
	}
	public void setNitComercio(String nitComercio) {
		this.nitComercio = nitComercio;
	}
	public String getCuComercio() {
		return cuComercio;
	}
	public void setCuComercio(String cuComercio) {
		this.cuComercio = cuComercio;
	}
	public String getNombreComercio() {
		return nombreComercio;
	}
	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}
	public String getNumeroTerminal() {
		return numeroTerminal;
	}
	public void setNumeroTerminal(String numeroTerminal) {
		this.numeroTerminal = numeroTerminal;
	}
	public String getNombrePasarela() {
		return nombrePasarela;
	}
	public void setNombrePasarela(String nombrePasarela) {
		this.nombrePasarela = nombrePasarela;
	}
	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}
	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}
	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}
	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}
	@Override
	public String toString() {
		return "RegistroTerminalRequest [activo=" + activo + ", nitComercio=" + nitComercio + ", cuComercio="
				+ cuComercio + ", nombreComercio=" + nombreComercio + ", numeroTerminal=" + numeroTerminal
				+ ", nombrePasarela=" + nombrePasarela + ", usuarioCreacion=" + usuarioCreacion
				+ ", usuarioModificacion=" + usuarioModificacion + "]";
	}

}
