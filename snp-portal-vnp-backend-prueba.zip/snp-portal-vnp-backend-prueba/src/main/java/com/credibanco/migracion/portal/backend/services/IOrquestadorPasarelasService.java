package com.credibanco.migracion.portal.backend.services;

import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.*;

import javax.xml.parsers.ParserConfigurationException;

public interface IOrquestadorPasarelasService {

    public OrquestadorPasarelasDTO crearTerminal(OrquestadorPasarelasCreateRequestDTO orquestadorPasarelasCreateRequestDTO, String ususario) throws PortalBackendException;

    public OrquestadorPasarelasModificarResponseDTO modificarTerminal(OrquestadorPasarelasModificarRequestDTO orquestadorPasarelasModificarRequestDTO, String ususario) throws PortalBackendException, ParserConfigurationException;

    public OrquestadorPasarelasInactivarResponseDTO inactivarTerminal(String comercio, String terminal,String pasarela, String ususario) throws PortalBackendException;

}
