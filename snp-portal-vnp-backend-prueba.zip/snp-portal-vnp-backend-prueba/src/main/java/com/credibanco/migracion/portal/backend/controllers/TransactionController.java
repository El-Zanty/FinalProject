package com.credibanco.migracion.portal.backend.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.credibanco.migracion.portal.backend.models.dto.RestPageImpl;
import com.credibanco.migracion.portal.backend.services.ILogService;
import com.credibanco.migracion.portal.backend.services.ITransactionService;
import com.credibanco.migracion.portal.backend.utils.JWTUtil;
import com.credibanco.migracion.portal.backend.utils.WriteCsvToResponse;
import com.credibanco.migracion.transacciones.dto.TransactionUnrestricted;

@RestController
@RequestMapping("/transacciones")
@CrossOrigin(origins = "*")
public class TransactionController {
	
	@Autowired
	private ITransactionService servicioTransacciones;
	
	@Autowired
	private ILogService logService;
	
	@GetMapping(value="/to-csv" ,produces = "text/csv")
	public void getTransactions(@RequestHeader(name = "Authorization") String token,
								@RequestParam MultiValueMap<String, String> condiciones, 
								HttpServletRequest request,
								HttpServletResponse response) throws Exception {
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Transacción CSV", "Obtener", request.getRemoteAddr().toString(), condiciones.toString(), null));
		WriteCsvToResponse.writeTransacions(response.getWriter(), servicioTransacciones.getTransacciones(condiciones));
	}
	
	@GetMapping
	public RestPageImpl<TransactionUnrestricted> getTransactionsPaginado(	@RequestHeader(name = "Authorization") String token,
																@RequestParam MultiValueMap<String, String> condiciones, 
																HttpServletRequest request) throws Exception {
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Transacción", "Obtener", request.getRemoteAddr().toString(), condiciones.toString(), null));
		return servicioTransacciones.getTransaccionesPaginado(condiciones);
	}
}
