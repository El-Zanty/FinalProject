package com.credibanco.migracion.portal.backend.models.dto;

public class OrquestadorPasarelasModificarRequestDTO {


        private String codigoUnico;
        private String[] funcionalidadesPrincipales;
        private String terminal;
        private String tipoComercio;
        private String pasarela;
        private String usuario;

    public String getCodigoUnico() {
        return codigoUnico;
    }

    public void setCodigoUnico(String codigoUnico) {
        this.codigoUnico = codigoUnico;
    }

    public String[] getFuncionalidadesPrincipales() {
        return funcionalidadesPrincipales;
    }

    public void setFuncionalidadesPrincipales(String[] funcionalidadesPrincipales) {
        this.funcionalidadesPrincipales = funcionalidadesPrincipales;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public String getTipoComercio() {
        return tipoComercio;
    }

    public void setTipoComercio(String tipoComercio) {
        this.tipoComercio = tipoComercio;
    }

    public String getPasarela() {
        return pasarela;
    }

    public void setPasarela(String pasarela) {
        this.pasarela = pasarela;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
}

