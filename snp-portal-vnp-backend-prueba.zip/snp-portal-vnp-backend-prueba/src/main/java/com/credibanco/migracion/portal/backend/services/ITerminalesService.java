package com.credibanco.migracion.portal.backend.services;

import javax.xml.parsers.ParserConfigurationException;

import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.CrearTerminalRequestDto;
import com.credibanco.migracion.portal.backend.models.dto.CrearTerminalResponseDto;
import com.credibanco.migracion.portal.backend.models.dto.DesactivarTerminalResponseDto;
import com.credibanco.migracion.portal.backend.models.dto.Terminal;
import com.credibanco.migracion.portal.backend.models.dto.TerminalData;

public interface ITerminalesService {
	public CrearTerminalResponseDto crearTerminal(CrearTerminalRequestDto crearTerminalRequestDto) throws PortalBackendException;

	public CrearTerminalResponseDto modificarTerminal(CrearTerminalRequestDto crearTerminalRequestDto, Terminal terminalDataAntes) throws PortalBackendException, ParserConfigurationException;

	public DesactivarTerminalResponseDto desactivarTerminal(String idTerminal, String cu) throws PortalBackendException;
	
	public TerminalData consultarTerminal(String idTerminal) throws ParserConfigurationException, PortalBackendException;
	
	public Terminal consultaTerminalModificacion(String idTerminal) throws ParserConfigurationException, PortalBackendException;
}
