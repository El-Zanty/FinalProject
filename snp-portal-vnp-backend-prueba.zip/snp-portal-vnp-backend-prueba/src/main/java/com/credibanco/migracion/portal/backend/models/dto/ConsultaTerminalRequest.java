package com.credibanco.migracion.portal.backend.models.dto;

public class ConsultaTerminalRequest {
	
	private String operation;
	private String code;
	
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	@Override
	public String toString() {
		return "ConsultaTerminalRequest [operation=" + operation + ", code=" + code + "]";
	}
	
	
}
