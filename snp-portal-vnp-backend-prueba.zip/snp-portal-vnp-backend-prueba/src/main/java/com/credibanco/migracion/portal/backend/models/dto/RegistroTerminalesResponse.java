package com.credibanco.migracion.portal.backend.models.dto;

import java.util.List;

public class RegistroTerminalesResponse {
	
	private List<RegistroTerminalResponse> terminales;

	public List<RegistroTerminalResponse> getTerminales() {
		return terminales;
	}

	public void setTerminales(List<RegistroTerminalResponse> terminales) {
		this.terminales = terminales;
	}

	@Override
	public String toString() {
		return "RegistroTerminalesResponse [terminales=" + terminales + "]";
	}
	
}
