package com.credibanco.migracion.portal.backend.models.dto;

import java.math.BigInteger;

public class OrquestadorPasarelasCreateRequestDTO {


        private BigInteger cantidadTerminales;
        private String codigoUnico;
        private String[] funcionalidadesPrincipales;
        private String tipoComercio;
        private String pasarela;
        private String usuario;



    public BigInteger getCantidadTerminales() {
        return cantidadTerminales;
    }

    public void setCantidadTerminales(BigInteger cantidadTerminales) {
        this.cantidadTerminales = cantidadTerminales;
    }

    public String getCodigoUnico() {
        return codigoUnico;
    }

    public void setCodigoUnico(String codigoUnico) {
        this.codigoUnico = codigoUnico;
    }

    public String[] getFuncionalidadesPrincipales() {
        return funcionalidadesPrincipales;
    }

    public void setFuncionalidadesPrincipales(String[] funcionalidadesPrincipales) {
        this.funcionalidadesPrincipales = funcionalidadesPrincipales;
    }

    public String getTipoComercio() {
        return tipoComercio;
    }

    public void setTipoComercio(String tipoComercio) {
        this.tipoComercio = tipoComercio;
    }

    public String getPasarela() {
        return pasarela;
    }

    public void setPasarela(String pasarela) {
        this.pasarela = pasarela;
    }

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
}
