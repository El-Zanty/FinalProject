package com.credibanco.migracion.portal.backend.services;

import java.util.List;

import org.springframework.util.MultiValueMap;

import com.credibanco.migracion.portal.backend.models.dto.RestPageImpl;
import com.credibanco.migracion.transacciones.dto.Log;
import com.credibanco.migracion.transacciones.dto.TransactionUnrestricted;

public interface ITransactionService {
	
	public List<TransactionUnrestricted> getTransacciones(MultiValueMap<String, String> condiciones);
	
	public RestPageImpl<TransactionUnrestricted> getTransaccionesPaginado(MultiValueMap<String, String> condiciones);

	public Void postLog(Log log);
}
