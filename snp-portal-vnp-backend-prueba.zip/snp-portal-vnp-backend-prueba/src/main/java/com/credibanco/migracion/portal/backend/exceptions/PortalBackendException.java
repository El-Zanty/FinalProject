package com.credibanco.migracion.portal.backend.exceptions;

public class PortalBackendException extends Exception{
	private static final long serialVersionUID = 1L;
	
	private ErrorDetails error; 

	public PortalBackendException() {
		super();
	}

	public PortalBackendException(ErrorDetails error) {
		super();
		this.error = error;
	}

	public ErrorDetails getError() {
		return error;
	}

	public void setError(ErrorDetails error) {
		this.error = error;
	}

	@Override
	public String toString() {
		return "PortalBackendException [error=" + error + "]";
	}
	
}
