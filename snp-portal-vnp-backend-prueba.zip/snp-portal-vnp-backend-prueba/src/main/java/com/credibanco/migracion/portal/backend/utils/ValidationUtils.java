package com.credibanco.migracion.portal.backend.utils;

public final class ValidationUtils {

    public static boolean isInteger( String input ) {
        try {
            Long.parseLong( input );
            return true;
        }
        catch( NumberFormatException e ) {
            return false;
        }
    }
}
