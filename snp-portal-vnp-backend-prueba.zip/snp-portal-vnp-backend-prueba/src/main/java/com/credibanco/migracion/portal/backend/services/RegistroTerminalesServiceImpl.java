package com.credibanco.migracion.portal.backend.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.credibanco.migracion.portal.backend.utils.ValidationUtils;
import com.credibanco.migracion.portal.backend.clients.SVRegistroTerminalesClient;
import com.credibanco.migracion.portal.backend.exceptions.ErrorDetails;
import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.PasarelaDTO;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalRequest;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalResponse;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalesResquest;
import com.credibanco.migracion.portal.backend.utils.MapperUtils;

@Service
public class RegistroTerminalesServiceImpl implements IRegistroTerminalesService {
	
	@Autowired
	private SVRegistroTerminalesClient registroTerminalesClient;
	
	@Autowired
	private PasarelasService pasarelasService;
	
	public List<RegistroTerminalResponse> obtenerTerminales(){
		return registroTerminalesClient.getTerminales();
	}
	
	public List<RegistroTerminalResponse> registrarTerminales(List<RegistroTerminalRequest> terminales, String username) throws PortalBackendException{
		List<RegistroTerminalRequest> terminalesValidas = new ArrayList<RegistroTerminalRequest>();
		List<RegistroTerminalResponse> terminalesResponse = new ArrayList<RegistroTerminalResponse>();
		List<PasarelaDTO> listaPasarelas = pasarelasService.getPasarelas();
		for(RegistroTerminalRequest terminal: terminales) {
			terminal.setUsuarioCreacion(username);
			if(this.pasarelaValida(terminal.getNombrePasarela(), listaPasarelas)) {
				terminalesValidas.add(terminal);
			}else {
				RegistroTerminalResponse terminalResponse= MapperUtils.mapObject(terminal, RegistroTerminalResponse.class);
				terminalResponse.setEstadoGuardado("Error: Pasarela erronea");
				terminalesResponse.add(terminalResponse);
			}
		}
		terminalesResponse.addAll(registroTerminalesClient.postTerminales(new RegistroTerminalesResquest(terminalesValidas)).getTerminales());
		return terminalesResponse;
	}

	
    private Boolean pasarelaValida(String pasarela, List<PasarelaDTO> listaPasarelas) throws PortalBackendException {
        return listaPasarelas.stream().map(PasarelaDTO::getUsuario).filter(pasarela::equals).findFirst().isPresent();
    }
     
	@Override
	public RegistroTerminalResponse actualizarTerminal(RegistroTerminalRequest terminal) throws PortalBackendException {
		List<PasarelaDTO> listaPasarelas = pasarelasService.getPasarelas();
		if(!this.pasarelaValida(terminal.getNombrePasarela(), listaPasarelas))
			throw new PortalBackendException(new ErrorDetails(new Date(), "Pasarela Erronea", "No se encuentra la pasarela."));
		else if(terminal.getNombreComercio()==null || terminal.getNombreComercio().length() > 150 ) {
			throw new PortalBackendException(new ErrorDetails(new Date(), "Nombre Comercio Erroneo", "Nombre comercio no puede estar vacio y debe ser de maximo 150 caracteres alfanuméricos."));
		}
		else if(terminal.getNitComercio()==null || terminal.getNitComercio().length() > 12|| !ValidationUtils.isInteger(terminal.getNitComercio())) {
			throw new PortalBackendException(new ErrorDetails(new Date(), "Nit Comercio Erroneo", "Nit comercio no puede estar vacio y debe ser de maximo 12 caracteres numéricos."));
		}
		else if(terminal.getCuComercio()==null || terminal.getCuComercio().length() > 12|| !ValidationUtils.isInteger(terminal.getCuComercio())) {
			throw new PortalBackendException(new ErrorDetails(new Date(), "Nit Comercio Erroneo", "CU comercio no puede estar vacio y debe ser de maximo 12 caracteres numéricos."));
		}
		return registroTerminalesClient.putTerminal(terminal);
	}

}
