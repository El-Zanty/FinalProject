package com.credibanco.migracion.portal.backend.models.dto;

public class DireccionTerminalDto {
	private String pais;
	private String direccionNumero;
	private String codigoRegion;
	private Integer latitud;
	private Integer longitud;
	
	public DireccionTerminalDto() {
		super();
	}

	public DireccionTerminalDto(String pais, String direccionNumero, String codigoRegion, Integer latitud,
			Integer longitud) {
		super();
		this.pais = pais;
		this.direccionNumero = direccionNumero;
		this.codigoRegion = codigoRegion;
		this.latitud = latitud;
		this.longitud = longitud;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getDireccionNumero() {
		return direccionNumero;
	}

	public void setDireccionNumero(String direccionNumero) {
		this.direccionNumero = direccionNumero;
	}

	public String getCodigoRegion() {
		return codigoRegion;
	}

	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	public Integer getLatitud() {
		return latitud;
	}

	public void setLatitud(Integer latitud) {
		this.latitud = latitud;
	}

	public Integer getLongitud() {
		return longitud;
	}

	public void setLongitud(Integer longitud) {
		this.longitud = longitud;
	}

	@Override
	public String toString() {
		return "DireccionTerminalDto [pais=" + pais + ", direccionNumero=" + direccionNumero + ", codigoRegion="
				+ codigoRegion + ", latitud=" + latitud + ", longitud=" + longitud + "]";
	}
	
}
