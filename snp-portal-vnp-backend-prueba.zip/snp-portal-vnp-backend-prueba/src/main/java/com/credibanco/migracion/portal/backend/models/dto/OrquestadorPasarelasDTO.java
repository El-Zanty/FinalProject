package com.credibanco.migracion.portal.backend.models.dto;

public class OrquestadorPasarelasDTO {

    private String codigoRespuesta;
    private String descripcion;
    private String[] terminalesCreadas;

    public String getCodigoRespuesta() {
        return codigoRespuesta;
    }

    public void setCodigoRespuesta(String codigoRespuesta) {
        this.codigoRespuesta = codigoRespuesta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String[] getTerminalesCreadas() {
        return terminalesCreadas;
    }

    public void setTerminalesCreadas(String[] terminalesCreadas) {
        this.terminalesCreadas = terminalesCreadas;
    }
}
