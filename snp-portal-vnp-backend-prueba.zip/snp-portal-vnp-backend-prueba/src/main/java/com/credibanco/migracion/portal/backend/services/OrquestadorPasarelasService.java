package com.credibanco.migracion.portal.backend.services;

import com.credibanco.migracion.portal.backend.clients.SVOrquestadorPasarelasClient;
import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.xml.parsers.ParserConfigurationException;

@Service
public class OrquestadorPasarelasService implements IOrquestadorPasarelasService{

    private static final Logger LOGGER = LoggerFactory.getLogger(OrquestadorPasarelasService.class);


    private SVOrquestadorPasarelasClient svOrquestadorPasarelasClient;

    public OrquestadorPasarelasService(SVOrquestadorPasarelasClient svOrquestadorPasarelasClient) {
        this.svOrquestadorPasarelasClient = svOrquestadorPasarelasClient;
    }

    @Override
    public OrquestadorPasarelasDTO crearTerminal(OrquestadorPasarelasCreateRequestDTO orquestadorPasarelasCreateRequestDTO, String usuario) throws PortalBackendException {
        LOGGER.info("crearTerminal(): consumiendo client orquestador pasarela");
        OrquestadorPasarelasDTO result = svOrquestadorPasarelasClient.postCrearTerminal(orquestadorPasarelasCreateRequestDTO, usuario);

        return result;
    }

    @Override
    public OrquestadorPasarelasModificarResponseDTO modificarTerminal(OrquestadorPasarelasModificarRequestDTO orquestadorPasarelasModificarRequestDTO, String usuario) throws PortalBackendException, ParserConfigurationException {
        LOGGER.info("crearTerminal(): consumiendo client orquestador pasarela modificacion");
        OrquestadorPasarelasModificarResponseDTO result = svOrquestadorPasarelasClient.putModificarterminal(orquestadorPasarelasModificarRequestDTO, usuario);
        return result;
    }

    @Override
    public OrquestadorPasarelasInactivarResponseDTO inactivarTerminal(String comercio, String terminal, String pasarela, String usuario) throws PortalBackendException {
        LOGGER.info("crearTerminal(): consumiendo client orquestador pasarela inhabilitar");
        OrquestadorPasarelasInactivarResponseDTO result = svOrquestadorPasarelasClient.deleteterminal(comercio, terminal, pasarela, usuario);
        return result;
    }
}
