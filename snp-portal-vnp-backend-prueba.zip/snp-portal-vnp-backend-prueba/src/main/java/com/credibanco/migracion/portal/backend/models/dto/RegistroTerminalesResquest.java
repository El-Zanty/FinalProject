package com.credibanco.migracion.portal.backend.models.dto;

import java.util.List;

public class RegistroTerminalesResquest {
	
	private List<RegistroTerminalRequest> terminales;

	public RegistroTerminalesResquest(List<RegistroTerminalRequest> terminales) {
		this.terminales = terminales;
	}

	public List<RegistroTerminalRequest> getTerminales() {
		return terminales;
	}

	public void setTerminales(List<RegistroTerminalRequest> terminales) {
		this.terminales = terminales;
	}

	@Override
	public String toString() {
		return "RegistroTerminalesResquest [terminales=" + terminales + "]";
	}
}
