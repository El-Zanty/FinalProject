package com.credibanco.migracion.portal.backend.services;

import com.credibanco.migracion.transacciones.dto.Log;

public interface ILogService {
	
	public void saveLog(Log log);
	
	public Log construirObjetoLog(String usuario, String objeto, String accion, String ip, String despues, String antes);

}
