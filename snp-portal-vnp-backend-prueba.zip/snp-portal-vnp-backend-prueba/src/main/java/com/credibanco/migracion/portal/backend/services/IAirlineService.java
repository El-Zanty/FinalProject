package com.credibanco.migracion.portal.backend.services;

import java.util.List;

import com.credibanco.migracion.portal.backend.models.entity.Airline;

public interface IAirlineService {

	public Airline findAirlineById(Integer id);
	
	public Airline modificarAerolinea(Airline airline);
	
	public List<Airline> findAll();
}
