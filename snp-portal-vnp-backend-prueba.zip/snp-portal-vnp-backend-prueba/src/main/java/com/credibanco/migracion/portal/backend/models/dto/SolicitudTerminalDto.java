package com.credibanco.migracion.portal.backend.models.dto;

import java.util.List;

public class SolicitudTerminalDto {
	private Integer cantidadTerminales;
	private List<String> idTerminales;
	private String dueno;
	private String tipoDispositivo;
	private String tipoComunicacion;
	private String tipoIntegracionTEF;
	private String marcaDispositivo;
	private String indicadorIca;
	private String indicadorIva;
	private List<String> idServicio;
	private Integer indicadorPropina;
	private Integer indicadorDeReferencia;
	private Integer indicadorCvv2;
	private TerminalGenericaDireccionDto direccionDeInstalacion;
	private String estadoTerminal;
	private String razonEstado;
	private String serial;
	private String sello;
	private String numeroCaja;
	private String codigoArrendamiento;
	private String fechaDeseada;
	private String fechaRetiroProgramado;
	private String numeroTerminalFisicaMulticomercio;
	private String observaciones;
	
	public SolicitudTerminalDto() {
		super();
	}

	public SolicitudTerminalDto(Integer cantidadTerminales, List<String> idTerminales, String dueno,
			String tipoDispositivo, String tipoComunicacion, String tipoIntegracionTEF, String marcaDispositivo,
			String indicadorIca, String indicadorIva, List<String> idServicio, Integer indicadorPropina,
			Integer indicadorDeReferencia, Integer indicadorCvv2, TerminalGenericaDireccionDto direccionDeInstalacion,
			String estadoTerminal, String razonEstado, String serial, String sello, String numeroCaja,
			String codigoArrendamiento, String fechaDeseada, String fechaRetiroProgramado,
			String numeroTerminalFisicaMulticomercio, String observaciones) {
		super();
		this.cantidadTerminales = cantidadTerminales;
		this.idTerminales = idTerminales;
		this.dueno = dueno;
		this.tipoDispositivo = tipoDispositivo;
		this.tipoComunicacion = tipoComunicacion;
		this.tipoIntegracionTEF = tipoIntegracionTEF;
		this.marcaDispositivo = marcaDispositivo;
		this.indicadorIca = indicadorIca;
		this.indicadorIva = indicadorIva;
		this.idServicio = idServicio;
		this.indicadorPropina = indicadorPropina;
		this.indicadorDeReferencia = indicadorDeReferencia;
		this.indicadorCvv2 = indicadorCvv2;
		this.direccionDeInstalacion = direccionDeInstalacion;
		this.estadoTerminal = estadoTerminal;
		this.razonEstado = razonEstado;
		this.serial = serial;
		this.sello = sello;
		this.numeroCaja = numeroCaja;
		this.codigoArrendamiento = codigoArrendamiento;
		this.fechaDeseada = fechaDeseada;
		this.fechaRetiroProgramado = fechaRetiroProgramado;
		this.numeroTerminalFisicaMulticomercio = numeroTerminalFisicaMulticomercio;
		this.observaciones = observaciones;
	}

	public Integer getCantidadTerminales() {
		return cantidadTerminales;
	}

	public void setCantidadTerminales(Integer cantidadTerminales) {
		this.cantidadTerminales = cantidadTerminales;
	}

	public List<String> getIdTerminales() {
		return idTerminales;
	}

	public void setIdTerminales(List<String> idTerminales) {
		this.idTerminales = idTerminales;
	}

	public String getDueno() {
		return dueno;
	}

	public void setDueno(String dueno) {
		this.dueno = dueno;
	}

	public String getTipoDispositivo() {
		return tipoDispositivo;
	}

	public void setTipoDispositivo(String tipoDispositivo) {
		this.tipoDispositivo = tipoDispositivo;
	}

	public String getTipoComunicacion() {
		return tipoComunicacion;
	}

	public void setTipoComunicacion(String tipoComunicacion) {
		this.tipoComunicacion = tipoComunicacion;
	}

	public String getTipoIntegracionTEF() {
		return tipoIntegracionTEF;
	}

	public void setTipoIntegracionTEF(String tipoIntegracionTEF) {
		this.tipoIntegracionTEF = tipoIntegracionTEF;
	}

	public String getMarcaDispositivo() {
		return marcaDispositivo;
	}

	public void setMarcaDispositivo(String marcaDispositivo) {
		this.marcaDispositivo = marcaDispositivo;
	}

	public String getIndicadorIca() {
		return indicadorIca;
	}

	public void setIndicadorIca(String indicadorIca) {
		this.indicadorIca = indicadorIca;
	}

	public String getIndicadorIva() {
		return indicadorIva;
	}

	public void setIndicadorIva(String indicadorIva) {
		this.indicadorIva = indicadorIva;
	}

	public List<String> getIdServicio() {
		return idServicio;
	}

	public void setIdServicio(List<String> idServicio) {
		this.idServicio = idServicio;
	}

	public Integer getIndicadorPropina() {
		return indicadorPropina;
	}

	public void setIndicadorPropina(Integer indicadorPropina) {
		this.indicadorPropina = indicadorPropina;
	}

	public Integer getIndicadorDeReferencia() {
		return indicadorDeReferencia;
	}

	public void setIndicadorDeReferencia(Integer indicadorDeReferencia) {
		this.indicadorDeReferencia = indicadorDeReferencia;
	}

	public Integer getIndicadorCvv2() {
		return indicadorCvv2;
	}

	public void setIndicadorCvv2(Integer indicadorCvv2) {
		this.indicadorCvv2 = indicadorCvv2;
	}

	public TerminalGenericaDireccionDto getDireccionDeInstalacion() {
		return direccionDeInstalacion;
	}

	public void setDireccionDeInstalacion(TerminalGenericaDireccionDto direccionDeInstalacion) {
		this.direccionDeInstalacion = direccionDeInstalacion;
	}

	public String getEstadoTerminal() {
		return estadoTerminal;
	}

	public void setEstadoTerminal(String estadoTerminal) {
		this.estadoTerminal = estadoTerminal;
	}

	public String getRazonEstado() {
		return razonEstado;
	}

	public void setRazonEstado(String razonEstado) {
		this.razonEstado = razonEstado;
	}

	public String getSerial() {
		return serial;
	}

	public void setSerial(String serial) {
		this.serial = serial;
	}

	public String getSello() {
		return sello;
	}

	public void setSello(String sello) {
		this.sello = sello;
	}

	public String getNumeroCaja() {
		return numeroCaja;
	}

	public void setNumeroCaja(String numeroCaja) {
		this.numeroCaja = numeroCaja;
	}

	public String getCodigoArrendamiento() {
		return codigoArrendamiento;
	}

	public void setCodigoArrendamiento(String codigoArrendamiento) {
		this.codigoArrendamiento = codigoArrendamiento;
	}

	public String getFechaDeseada() {
		return fechaDeseada;
	}

	public void setFechaDeseada(String fechaDeseada) {
		this.fechaDeseada = fechaDeseada;
	}

	public String getFechaRetiroProgramado() {
		return fechaRetiroProgramado;
	}

	public void setFechaRetiroProgramado(String fechaRetiroProgramado) {
		this.fechaRetiroProgramado = fechaRetiroProgramado;
	}

	public String getNumeroTerminalFisicaMulticomercio() {
		return numeroTerminalFisicaMulticomercio;
	}

	public void setNumeroTerminalFisicaMulticomercio(String numeroTerminalFisicaMulticomercio) {
		this.numeroTerminalFisicaMulticomercio = numeroTerminalFisicaMulticomercio;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	@Override
	public String toString() {
		return "SolicitudTerminalDto [cantidadTerminales=" + cantidadTerminales + ", idTerminales=" + idTerminales
				+ ", dueno=" + dueno + ", tipoDispositivo=" + tipoDispositivo + ", tipoComunicacion=" + tipoComunicacion
				+ ", tipoIntegracionTEF=" + tipoIntegracionTEF + ", marcaDispositivo=" + marcaDispositivo
				+ ", indicadorIca=" + indicadorIca + ", indicadorIva=" + indicadorIva + ", idServicio=" + idServicio
				+ ", indicadorPropina=" + indicadorPropina + ", indicadorDeReferencia=" + indicadorDeReferencia
				+ ", indicadorCvv2=" + indicadorCvv2 + ", estadoTerminal=" + estadoTerminal + ", razonEstado="
				+ razonEstado + ", serial=" + serial + ", sello=" + sello + ", numeroCaja=" + numeroCaja
				+ ", codigoArrendamiento=" + codigoArrendamiento + ", fechaDeseada=" + fechaDeseada
				+ ", fechaRetiroProgramado=" + fechaRetiroProgramado + ", numeroTerminalFisicaMulticomercio="
				+ numeroTerminalFisicaMulticomercio + ", observaciones=" + observaciones + "]";
	}
	
}
