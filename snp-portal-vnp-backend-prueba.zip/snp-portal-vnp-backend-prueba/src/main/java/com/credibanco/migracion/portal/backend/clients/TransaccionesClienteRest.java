package com.credibanco.migracion.portal.backend.clients;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.credibanco.migracion.portal.backend.exceptions.ResourceNotFoundException;
import com.credibanco.migracion.portal.backend.exceptions.TransactionException;
import com.credibanco.migracion.portal.backend.models.dto.RestPageImpl;
import com.credibanco.migracion.portal.backend.services.ITransactionService;
import com.credibanco.migracion.transacciones.dto.BusquedaTransaccionDto;
import com.credibanco.migracion.transacciones.dto.Log;
import com.credibanco.migracion.transacciones.dto.TransactionUnrestricted;

@Component
@PropertySource("classpath:application.properties")
public class TransaccionesClienteRest implements ITransactionService{
	
	@Value("${credibanco.error.codes.error_interno}")
	private String codigoErrorInterno;
	
	@Value("${credibanco.error.messages.error_interno}")
	private String mensajeErrorInterno;
	
	@Value("${credibanco.client.svtransacciones.url}")
	private String svTransaccionesUrl;
	
	@Value("${credibanco.client.svtransacciones.consulta.path}")
	private String svTransaccionesConsultaPath;
	
	@Value("${credibanco.client.svtransacciones.consulta.path.paginado}")
	private String svTransaccionesConsultaPathPaginado;
	
	@Value("${credibanco.client.svtransacciones.consulta.path.log}")
	private String svTransaccionesLog;
	
	@Value("${credibanco.client.svtransacciones.consulta.timeout}")
	private int svTransaccionesConsultaTimeout;
	
    @Value("${credibanco.client.svtransacciones.consulta.username}")
    private String transactionsUsername;
    
    @Value("${credibanco.client.svtransacciones.consulta.password}")
    private String transactionsPassword;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TransaccionesClienteRest.class);
	
	public List<TransactionUnrestricted> getTransacciones(MultiValueMap<String, String> condiciones){
		
		RestTemplate restTemplate = restTemplateWithTimeout(svTransaccionesConsultaTimeout);
		
		UriComponentsBuilder uriBuilder = 	
				UriComponentsBuilder.fromHttpUrl(svTransaccionesUrl)
									.path(svTransaccionesConsultaPath)
									.queryParams(condiciones);
		
		String uri = uriBuilder.toUriString();
		
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBasicAuth(transactionsUsername, transactionsPassword);
		
		HttpEntity<BusquedaTransaccionDto> entity = new HttpEntity<>(null, headers);
		
		ResponseEntity<TransactionUnrestricted[]> result = null;
		
		try {
			LOGGER.info(String.format("getTransaction(): Enviando solicitud WS Transacciones, url = %s ", uri));
			result = restTemplate.exchange(uri, HttpMethod.GET, entity, TransactionUnrestricted[].class);
			return Arrays.asList(result.getBody());
		}catch(HttpStatusCodeException e) {
			LOGGER.error("getTransaction(): Error en el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
		}catch(RestClientException  e) {
			LOGGER.error("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException(e.getMessage());
		}catch(Exception e) {
			LOGGER.error("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException(e.getMessage());
		}
	}
	
	
	public RestPageImpl<TransactionUnrestricted> getTransaccionesPaginado(MultiValueMap<String, String> condiciones){
		
		RestTemplate restTemplate = restTemplateWithTimeout(svTransaccionesConsultaTimeout);
		
		UriComponentsBuilder uriBuilder = 	
				UriComponentsBuilder.fromHttpUrl(svTransaccionesUrl)
									.path(svTransaccionesConsultaPathPaginado)
									.queryParams(condiciones);
		
		String uri = uriBuilder.toUriString();
		
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBasicAuth(transactionsUsername, transactionsPassword);
		
		HttpEntity<BusquedaTransaccionDto> entity = new HttpEntity<>(null, headers);
		
		ResponseEntity<RestPageImpl<TransactionUnrestricted>> result = null;
		
		try {
			LOGGER.info(String.format("getTransaction(): Enviando solicitud WS Transacciones, url = %s ", uri));
			result = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<RestPageImpl<TransactionUnrestricted>>() {});
			return result.getBody();
		}catch(HttpStatusCodeException e) {
			LOGGER.error("getTransaction(): Error en el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			if(e.getStatusCode().value()==404)
				throw new ResourceNotFoundException("No se encontraron resultados");
			else
				throw new TransactionException("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
		}catch(RestClientException  e) {
			LOGGER.error("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
		}catch(Exception e) {
			LOGGER.error("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
		}
	}
	
	public Void postLog(Log log){
		
		RestTemplate restTemplate = restTemplateWithTimeout(svTransaccionesConsultaTimeout);
		
		UriComponentsBuilder uriBuilder = 	
				UriComponentsBuilder.fromHttpUrl(svTransaccionesUrl)
									.path(svTransaccionesLog);
		
		String uri = uriBuilder.toUriString();
		
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBasicAuth(transactionsUsername, transactionsPassword);
		
		HttpEntity<Log> entity = new HttpEntity<>(log, headers);
		
		ResponseEntity<Void> result = null;
		
		try {
			LOGGER.info(String.format("getTransaction(): Enviando solicitud WS Transacciones, url = %s ", uri));
			result = restTemplate.exchange(uri, HttpMethod.POST, entity, Void.class);
			return result.getBody();
		}catch(HttpStatusCodeException e) {
			LOGGER.error("postLog(): Error en el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException("postLog(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
		}catch(RestClientException  e) {
			LOGGER.error("postLog(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException("postLog(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
		}catch(Exception e) {
			LOGGER.error("postLog(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException("postLog(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
		}
	}

	private RestTemplate restTemplateWithTimeout(int timeout) {
		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
		= new HttpComponentsClientHttpRequestFactory();
		clientHttpRequestFactory.setConnectTimeout(timeout);
		return new RestTemplate(clientHttpRequestFactory);
	}
	
}
