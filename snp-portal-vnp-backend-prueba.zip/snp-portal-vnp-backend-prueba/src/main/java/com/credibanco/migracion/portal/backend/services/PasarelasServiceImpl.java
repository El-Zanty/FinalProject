package com.credibanco.migracion.portal.backend.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.credibanco.migracion.portal.backend.clients.SSOAPIClient;
import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.PasarelaDTO;
import com.credibanco.migracion.portal.backend.models.dto.SSOTokenDTO;
import com.credibanco.migracion.portal.backend.models.dto.SSOUserDTO;

@Service
public class PasarelasServiceImpl implements PasarelasService{
	
	@Value("${credibanco.sso.api.group_id}")
	private String groupId;
	
	@Value("${credibanco.sso.api.realm_name}")
	private String realmName;
	
	private SSOAPIClient ssoApiClient;
	
	@Autowired
	public PasarelasServiceImpl(SSOAPIClient ssoApiClient) {
		this.ssoApiClient = ssoApiClient;
	}

	@Override
	//Esta funcion busca las usuarios en el SSO y los retorna como pasarelas
	public List<PasarelaDTO> getPasarelas() throws PortalBackendException {
		SSOTokenDTO ssoTokenDto = ssoApiClient.getTokenSession(realmName);
		List<SSOUserDTO> ssoUsers = ssoApiClient.getUsersFromGroupAndRealm(groupId, realmName, ssoTokenDto.getAccess_token());
		return ssoUsersToPasarelas(ssoUsers);
		
	}

	private List<PasarelaDTO> ssoUsersToPasarelas(List<SSOUserDTO> ssoUsers) {
		List<PasarelaDTO> pasarelas = new ArrayList<>();
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");  
		for(SSOUserDTO ssoUser : ssoUsers) {
			Date fecha = new Date(ssoUser.getCreatedTimestamp());
			String strFecha = dateFormat.format(fecha);
			PasarelaDTO pasarelaDTO = new PasarelaDTO(strFecha, ssoUser.getUsername(), ssoUser.getEmail(), ssoUser.getEnabled());
			pasarelas.add(pasarelaDTO);
		}
		return pasarelas;
	}
	
	
}
