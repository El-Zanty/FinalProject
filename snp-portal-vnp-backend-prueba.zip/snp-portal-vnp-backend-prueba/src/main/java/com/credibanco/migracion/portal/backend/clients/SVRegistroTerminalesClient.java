package com.credibanco.migracion.portal.backend.clients;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.credibanco.migracion.portal.backend.exceptions.TransactionException;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalRequest;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalResponse;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalesResponse;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalesResquest;

@Component
public class SVRegistroTerminalesClient {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SVRegistroTerminalesClient.class);
	
	@Value("${credibanco.error.codes.error_interno}")
	private String codigoErrorInterno;
	
	@Value("${credibanco.error.messages.error_interno}")
	private String mensajeErrorInterno;
	
	@Value("${credibanco.client.sv_registro_terminales.url}")
	private String svRegistroTerminalesUrl;
	
	@Value("${credibanco.client.sv_registro_terminales.consulta.path}")
	private String svRegistroTerminalesConsultaPath;
	
	@Value("${credibanco.client.sv_registro_terminales.consulta.timeout}")
	private int svRegistroTerminalesConsultaTimeout;
	
	public List<RegistroTerminalResponse> getTerminales(){
		
		RestTemplate restTemplate = restTemplateWithTimeout(svRegistroTerminalesConsultaTimeout);
		
		UriComponentsBuilder uriBuilder = 	
				UriComponentsBuilder.fromHttpUrl(svRegistroTerminalesUrl)
									.path(svRegistroTerminalesConsultaPath);
		
		String uri = uriBuilder.toUriString();
		
		HttpHeaders headers = new HttpHeaders();
		
		HttpEntity<?> entity = new HttpEntity<>(null, headers);
		
		ResponseEntity<RegistroTerminalResponse[]> result = null;
		
		try {
			LOGGER.info(String.format("getTransaction(): Enviando solicitud WS Transacciones, url = %s ", uri));
			result = restTemplate.exchange(uri, HttpMethod.GET, entity, RegistroTerminalResponse[].class);
			return Arrays.asList(result.getBody());
		}catch(HttpStatusCodeException e) {
			LOGGER.error("getTerminales(): Error en el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException("getTerminales(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
		}catch(RestClientException  e) {
			LOGGER.error("getTerminales(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException(e.getMessage());
		}catch(Exception e) {
			LOGGER.error("getTerminales(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException(e.getMessage());
		}
	}
	
	public RegistroTerminalesResponse postTerminales(RegistroTerminalesResquest terminales){
		
		RestTemplate restTemplate = restTemplateWithTimeout(svRegistroTerminalesConsultaTimeout);
		
		UriComponentsBuilder uriBuilder = 	
				UriComponentsBuilder.fromHttpUrl(svRegistroTerminalesUrl)
									.path(svRegistroTerminalesConsultaPath);
		
		String uri = uriBuilder.toUriString();
		
		HttpHeaders headers = new HttpHeaders();
		
		HttpEntity<RegistroTerminalesResquest> entity = new HttpEntity<>(terminales, headers);
		
		ResponseEntity<RegistroTerminalesResponse> result = null;
		
		try {
			LOGGER.info(String.format("getTransaction(): Enviando solicitud WS Transacciones, url = %s ", uri));
			result = restTemplate.exchange(uri, HttpMethod.POST, entity, RegistroTerminalesResponse.class);
			return result.getBody();
		}catch(HttpStatusCodeException e) {
			LOGGER.error("getTerminales(): Error en el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException("getTerminales(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
		}catch(RestClientException  e) {
			LOGGER.error("getTerminales(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException(e.getMessage());
		}catch(Exception e) {
			LOGGER.error("getTerminales(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException(e.getMessage());
		}
	}
	
	private RestTemplate restTemplateWithTimeout(int timeout){
		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
		= new HttpComponentsClientHttpRequestFactory();
		clientHttpRequestFactory.setConnectTimeout(timeout);
		clientHttpRequestFactory.setConnectionRequestTimeout(timeout);
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
		return restTemplate;
	}

	public RegistroTerminalResponse putTerminal(RegistroTerminalRequest terminal) {
		RestTemplate restTemplate = restTemplateWithTimeout(svRegistroTerminalesConsultaTimeout);
		
		UriComponentsBuilder uriBuilder = 	
				UriComponentsBuilder.fromHttpUrl(svRegistroTerminalesUrl)
									.path(svRegistroTerminalesConsultaPath);
		
		String uri = uriBuilder.toUriString();
		
		HttpHeaders headers = new HttpHeaders();
		
		HttpEntity<RegistroTerminalRequest> entity = new HttpEntity<>(terminal, headers);
		
		ResponseEntity<RegistroTerminalResponse> result = null;
		
		try {
			LOGGER.info(String.format("getTransaction(): Enviando solicitud WS Transacciones, url = %s ", uri));
			result = restTemplate.exchange(uri, HttpMethod.PUT, entity, RegistroTerminalResponse.class);
			return result.getBody();
		}catch(HttpStatusCodeException e) {
			LOGGER.error("putTerminales(): Error en el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException("getTerminales(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
		}catch(RestClientException  e) {
			LOGGER.error("putTerminales(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException(e.getMessage());
		}catch(Exception e) {
			LOGGER.error("putTerminales(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
			throw new TransactionException(e.getMessage());
		}
	}

}
