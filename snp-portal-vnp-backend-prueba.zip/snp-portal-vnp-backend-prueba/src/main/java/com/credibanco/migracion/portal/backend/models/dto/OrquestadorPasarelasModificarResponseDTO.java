package com.credibanco.migracion.portal.backend.models.dto;

public class OrquestadorPasarelasModificarResponseDTO {

   private String codigoRespuesta;
   private String descripcion;

    public String getCodigoRespuesta() {
        return codigoRespuesta;
    }

    public void setCodigoRespuesta(String codigoRespuesta) {
        this.codigoRespuesta = codigoRespuesta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
