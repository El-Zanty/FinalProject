package com.credibanco.migracion.portal.backend.models.dto;

import java.util.Date;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;

public class RegistroTerminalResponse {
	
	@CsvBindByPosition(position = 5)
	@CsvBindByName(column = "Estado Terminal")
	private Boolean activo;
	
	@CsvBindByPosition(position = 0)
	@CsvBindByName(column = "NIT Comercio")
	private String nitComercio;
	
	@CsvBindByPosition(position = 1)
	@CsvBindByName(column = "CU Comercio")
	private String cuComercio;
	
	@CsvBindByPosition(position = 2)
	@CsvBindByName(column = "Nombre del comercio")
	private String nombreComercio;
	
	@CsvBindByPosition(position = 3)
	@CsvBindByName(column = "Terminal del Comercio")
	private String numeroTerminal;
	
	@CsvBindByPosition(position = 4)
	@CsvBindByName(column = "Nombre Pasarela ")
	private String nombrePasarela;
	
	@CsvBindByPosition(position = 6)
	@CsvBindByName(column = "Estado guardado")
	private String estadoGuardado;
	
	@CsvBindByPosition(position = 7)
	@CsvBindByName(column = "Fecha Creacion")
	private Date fechaCreacion;
	
	@CsvBindByPosition(position = 8)
	@CsvBindByName(column = "Fecha Modificacion")
	private Date fechaModificacion;
	
	@CsvBindByPosition(position = 9)
	@CsvBindByName(column = "Usuario creacion")
	private String usuarioCreacion;
	
	@CsvBindByPosition(position = 10)
	@CsvBindByName(column = "Usuario Modificacion")
	private String usuarioModificacion;

	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	public String getNitComercio() {
		return nitComercio;
	}

	public void setNitComercio(String nitComercio) {
		this.nitComercio = nitComercio;
	}

	public String getCuComercio() {
		return cuComercio;
	}

	public void setCuComercio(String cuComercio) {
		this.cuComercio = cuComercio;
	}

	public String getNombreComercio() {
		return nombreComercio;
	}

	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}

	public String getNumeroTerminal() {
		return numeroTerminal;
	}

	public void setNumeroTerminal(String numeroTerminal) {
		this.numeroTerminal = numeroTerminal;
	}

	public String getNombrePasarela() {
		return nombrePasarela;
	}

	public void setNombrePasarela(String nombrePasarela) {
		this.nombrePasarela = nombrePasarela;
	}

	public String getEstadoGuardado() {
		return estadoGuardado;
	}

	public void setEstadoGuardado(String estadoGuardado) {
		this.estadoGuardado = estadoGuardado;
	}
	
	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RegistroTerminalResponse [");
		if (activo != null) {
			builder.append("activo=");
			builder.append(activo);
			builder.append(", ");
		}
		if (nitComercio != null) {
			builder.append("nitComercio=");
			builder.append(nitComercio);
			builder.append(", ");
		}
		if (cuComercio != null) {
			builder.append("cuComercio=");
			builder.append(cuComercio);
			builder.append(", ");
		}
		if (nombreComercio != null) {
			builder.append("nombreComercio=");
			builder.append(nombreComercio);
			builder.append(", ");
		}
		if (numeroTerminal != null) {
			builder.append("numeroTerminal=");
			builder.append(numeroTerminal);
			builder.append(", ");
		}
		if (nombrePasarela != null) {
			builder.append("nombrePasarela=");
			builder.append(nombrePasarela);
			builder.append(", ");
		}
		if (estadoGuardado != null) {
			builder.append("estadoGuardado=");
			builder.append(estadoGuardado);
			builder.append(", ");
		}
		if (fechaCreacion != null) {
			builder.append("fechaCreacion=");
			builder.append(fechaCreacion);
			builder.append(", ");
		}
		if (fechaModificacion != null) {
			builder.append("fechaModificacion=");
			builder.append(fechaModificacion);
			builder.append(", ");
		}
		if (usuarioCreacion != null) {
			builder.append("usuarioCreacion=");
			builder.append(usuarioCreacion);
			builder.append(", ");
		}
		if (usuarioModificacion != null) {
			builder.append("usuarioModificacion=");
			builder.append(usuarioModificacion);
		}
		builder.append("]");
		return builder.toString();
	}

	
}
