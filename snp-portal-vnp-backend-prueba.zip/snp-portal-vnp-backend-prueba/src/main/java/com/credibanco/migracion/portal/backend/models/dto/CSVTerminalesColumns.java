package com.credibanco.migracion.portal.backend.models.dto;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;

public class CSVTerminalesColumns {
	
	@CsvBindByPosition(position = 5)
	@CsvBindByName(column = "ESTADO_TERMINAL")
	private String activo;
	
	@CsvBindByPosition(position = 0)
	@CsvBindByName(column = "NIT_COMERCIO")
	private String nitComercio;
	
	@CsvBindByPosition(position = 1)
	@CsvBindByName(column = "CODIGO_UNICO")
	private String cuComercio;
	
	@CsvBindByPosition(position = 2)
	@CsvBindByName(column = "NOMBRE_DEL_COMERCIO")
	private String nombreComercio;
	
	@CsvBindByPosition(position = 3)
	@CsvBindByName(column = "NUMERO_TERMINAL")
	private String numeroTerminal;
	
	@CsvBindByPosition(position = 4)
	@CsvBindByName(column = "NOMBRE_PASARELA")
	private String nombrePasarela;
	
	public CSVTerminalesColumns() {}


	public CSVTerminalesColumns(String activo, String nitComercio, String cuComercio, String nombreComercio,
			String numeroTerminal, String nombrePasarela) {
		super();
		this.activo = activo;
		this.nitComercio = nitComercio;
		this.cuComercio = cuComercio;
		this.nombreComercio = nombreComercio;
		this.numeroTerminal = numeroTerminal;
		this.nombrePasarela = nombrePasarela;
	}


	public CSVTerminalesColumns(Long id,String nombrePasarela) {
		this.nitComercio = "10203040";
		this.cuComercio = "010203040";
		this.nombreComercio = "NOMBRE COMERCIO";
		this.numeroTerminal = "00001234";
		this.nombrePasarela = nombrePasarela;
		this.activo = "ACTIVO";
	}

	public String getActivo() {
		return activo;
	}
	public void setActivo(String activo) {
		this.activo = activo;
	}
	public String getNitComercio() {
		return nitComercio;
	}
	public void setNitComercio(String nitComercio) {
		this.nitComercio = nitComercio;
	}
	public String getCuComercio() {
		return cuComercio;
	}
	public void setCuComercio(String cuComercio) {
		this.cuComercio = cuComercio;
	}
	public String getNombreComercio() {
		return nombreComercio;
	}
	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}
	public String getNumeroTerminal() {
		return numeroTerminal;
	}
	public void setNumeroTerminal(String numeroTerminal) {
		this.numeroTerminal = numeroTerminal;
	}
	public String getNombrePasarela() {
		return nombrePasarela;
	}
	public void setNombrePasarela(String nombrePasarela) {
		this.nombrePasarela = nombrePasarela;
	}
	@Override
	public String toString() {
		return "CSVTerminalesColumns [activo=" + activo + ", nitComercio=" + nitComercio + ", cuComercio=" + cuComercio
				+ ", nombreComercio=" + nombreComercio + ", numeroTerminal=" + numeroTerminal + ", nombrePasarela="
				+ nombrePasarela + "]";
	}
}
