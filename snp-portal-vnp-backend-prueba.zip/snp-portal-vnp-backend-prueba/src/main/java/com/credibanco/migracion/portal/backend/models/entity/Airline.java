package com.credibanco.migracion.portal.backend.models.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "airlines")
public class Airline {
	
	@Id
	@Column(name = "id_aerolinea")
	private Integer id;
	
	private String name;
	
	private Integer nacional;
	
	@Column(name = "unique_code")
	private String uniqueCode;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getNacional() {
		return nacional;
	}
	public void setNacional(Integer nacional) {
		this.nacional = nacional;
	}
	public String getUniqueCode() {
		return uniqueCode;
	}
	public void setUniqueCode(String uniqueCode) {
		this.uniqueCode = uniqueCode;
	}
	@Override
	public String toString() {
		return "Airline [id=" + id + ", name=" + name + ", nacional=" + nacional + ", uniqueCode=" + uniqueCode + "]";
	}
	
	
}
