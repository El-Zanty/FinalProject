package com.credibanco.migracion.portal.backend.models.repository;

import org.springframework.data.repository.CrudRepository;

import com.credibanco.migracion.portal.backend.models.entity.Airline;

public interface AirlineDao extends CrudRepository<Airline, Integer>{

}
