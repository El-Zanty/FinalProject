package com.credibanco.migracion.portal.backend.controllers;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import com.credibanco.migracion.portal.backend.models.dto.AirlineDto;
import com.credibanco.migracion.portal.backend.models.entity.Airline;
import com.credibanco.migracion.portal.backend.services.IAirlineService;
import com.credibanco.migracion.portal.backend.services.ILogService;
import com.credibanco.migracion.portal.backend.utils.JWTUtil;

@RestController
@RequestMapping("/administracion")
@CrossOrigin(origins = "*")
public class AdministracionController {
	
	private static final Logger LOG = LoggerFactory.getLogger(AdministracionController.class);
	
	@Autowired
	private IAirlineService aerolineasService;
	
	@Autowired
	private ILogService logService;
	
	@GetMapping("/aerolineas")
	@ResponseStatus(code = HttpStatus.OK)
	public List<Airline> obtenerAerolineas(	@RequestHeader(name = "Authorization") String token,
											HttpServletRequest request) throws Exception{
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Aerolineas", "Consulta", request.getRemoteAddr(),null,null));
		return aerolineasService.findAll();
	}
	
	@GetMapping("/aerolineas/{id}")
	@ResponseStatus(code = HttpStatus.OK)
	public Airline obtenerAerolinea(@PathVariable Integer id){
		return aerolineasService.findAirlineById(id);
	}
	
	@PutMapping("/aerolineas")
	@ResponseStatus(code = HttpStatus.OK)
	public Airline modificarAerolinea(	@RequestBody AirlineDto airlineDto,
										@RequestHeader(name = "Authorization") String token,
										HttpServletRequest request) throws Exception {
		Airline airline = aerolineasService.findAirlineById(airlineDto.getId());
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Aerolineas", "Modificar", request.getRemoteAddr(), airlineDto.toString(), airline.toString()));
		return aerolineasService.modificarAerolinea(this.airlineDtotoAirlineMapper(airlineDto));
	}
	
	@PostMapping("/log")
	@ResponseStatus(code = HttpStatus.OK)
	public void registrarLog(	@RequestHeader(name = "Authorization") String token, @RequestParam String loginLog,
								HttpServletRequest request) throws Exception {
		String preferedUsername = JWTUtil.getPreferredUsernameFromPayloadJWT(token);
		LOG.info(loginLog + " de: " + preferedUsername);
		LOG.info("Client Ip: {}", this.getClientIp(request) );
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Login", loginLog, request.getRemoteAddr(), null, null));
	}
	
	private Airline airlineDtotoAirlineMapper(AirlineDto airlineDto) {
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		return modelMapper.map(airlineDto, Airline.class);
	}

	@GetMapping("/log")
	public String obtenerLogAuditoria() {
		return "Servicio de log.";
	}
	
	@GetMapping("/conexion")
	public String verificarConexion() {
		return "Servicio de verificación de conexión.";
	}
	
	
	@GetMapping("/consultas")
	public String consultasPredeterminadas() {
		return "Servicio de consultas pre-determinadas.";
	}
	
	private final String LOCALHOST_IPV4 = "127.0.0.1";
	private final String LOCALHOST_IPV6 = "0:0:0:0:0:0:0:1";
	
	public String getClientIp(HttpServletRequest request) {
		String ipAddress = request.getHeader("X-Forwarded-For");
		if(StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("Proxy-Client-IP");
		}
		
		if(StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("WL-Proxy-Client-IP");
		}
		
		if(StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getRemoteAddr();
			if(LOCALHOST_IPV4.equals(ipAddress) || LOCALHOST_IPV6.equals(ipAddress)) {
				try {
					InetAddress inetAddress = InetAddress.getLocalHost();
					ipAddress = inetAddress.getHostAddress();
				} catch (UnknownHostException e) {
					LOG.error("Error obteniendo la Ip de origen: {}", e);
				}
			}
		}
		
		if(!StringUtils.isEmpty(ipAddress) 
				&& ipAddress.length() > 15
				&& ipAddress.indexOf(",") > 0) {
			ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
		}
		
		return ipAddress;
	}

}
