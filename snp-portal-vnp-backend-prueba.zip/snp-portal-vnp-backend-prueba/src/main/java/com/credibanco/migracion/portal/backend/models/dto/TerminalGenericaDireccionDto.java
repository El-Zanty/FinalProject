package com.credibanco.migracion.portal.backend.models.dto;

public class TerminalGenericaDireccionDto {
	private String pais;
	private String direccionNumero;
	private String apartamentoOficina;
	private String codigoPostal;
	private String codigoRegion;
	private Integer latitud;
	private Integer longitud;
	
	public TerminalGenericaDireccionDto() {
		super();
	}
	
	public TerminalGenericaDireccionDto(String pais, String direccionNumero, String apartamentoOficina,
			String codigoPostal, String codigoRegion, Integer latitud, Integer longitud) {
		super();
		this.pais = pais;
		this.direccionNumero = direccionNumero;
		this.apartamentoOficina = apartamentoOficina;
		this.codigoPostal = codigoPostal;
		this.codigoRegion = codigoRegion;
		this.latitud = latitud;
		this.longitud = longitud;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getDireccionNumero() {
		return direccionNumero;
	}

	public void setDireccionNumero(String direccionNumero) {
		this.direccionNumero = direccionNumero;
	}

	public String getApartamentoOficina() {
		return apartamentoOficina;
	}

	public void setApartamentoOficina(String apartamentoOficina) {
		this.apartamentoOficina = apartamentoOficina;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public String getCodigoRegion() {
		return codigoRegion;
	}

	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}

	public Integer getLatitud() {
		return latitud;
	}

	public void setLatitud(Integer latitud) {
		this.latitud = latitud;
	}

	public Integer getLongitud() {
		return longitud;
	}

	public void setLongitud(Integer longitud) {
		this.longitud = longitud;
	}

	@Override
	public String toString() {
		return "TerminalGenericaDireccionDto [pais=" + pais + ", direccionNumero=" + direccionNumero
				+ ", apartamentoOficina=" + apartamentoOficina + ", codigoPostal=" + codigoPostal + ", codigoRegion="
				+ codigoRegion + ", latitud=" + latitud + ", longitud=" + longitud + "]";
	}
	
}
