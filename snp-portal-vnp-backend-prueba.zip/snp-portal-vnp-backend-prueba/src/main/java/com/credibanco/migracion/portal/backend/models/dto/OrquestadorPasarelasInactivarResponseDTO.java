package com.credibanco.migracion.portal.backend.models.dto;

public class OrquestadorPasarelasInactivarResponseDTO {

    private String codigoRespuesta;
    private String terminal;
    private String comercio;

    public String getCodigoRespuesta() {
        return codigoRespuesta;
    }

    public void setCodigoRespuesta(String codigoRespuesta) {
        this.codigoRespuesta = codigoRespuesta;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public String getComercio() {
        return comercio;
    }

    public void setComercio(String comercio) {
        this.comercio = comercio;
    }
}
