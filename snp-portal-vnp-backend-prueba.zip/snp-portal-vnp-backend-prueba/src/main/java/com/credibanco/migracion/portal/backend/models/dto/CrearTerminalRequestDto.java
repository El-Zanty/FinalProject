package com.credibanco.migracion.portal.backend.models.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class CrearTerminalRequestDto {
	
	@NotNull(message = "codigoOriginador es obligatorio")
	private String codigoOriginador;
	
	@NotNull(message = "codigoComercio es obligatorio")
	private String codigoComercio;
	
	@Valid
	@NotNull(message = "terminal es obligatorio")
	private SolicitudTerminales terminal;
	
	public CrearTerminalRequestDto() {
		super();
		this.codigoOriginador = "";
		this.codigoComercio = "";
		this.terminal = new SolicitudTerminales();
	}

	public CrearTerminalRequestDto(String codigoOriginador, String codigoComercio, SolicitudTerminales terminal) {
		super();
		this.codigoOriginador = codigoOriginador;
		this.codigoComercio = codigoComercio;
		this.terminal = terminal;
	}

	public String getCodigoOriginador() {
		return codigoOriginador;
	}

	public void setCodigoOriginador(String codigoOriginador) {
		this.codigoOriginador = codigoOriginador;
	}

	public String getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public SolicitudTerminales getTerminal() {
		return terminal;
	}

	public void setTerminal(SolicitudTerminales terminal) {
		this.terminal = terminal;
	}

	@Override
	public String toString() {
		return "CrearTerminalRequestDto [codigoOriginador=" + codigoOriginador + ", codigoComercio=" + codigoComercio
				+ ", terminal=" + terminal + "]";
	}
	
}
