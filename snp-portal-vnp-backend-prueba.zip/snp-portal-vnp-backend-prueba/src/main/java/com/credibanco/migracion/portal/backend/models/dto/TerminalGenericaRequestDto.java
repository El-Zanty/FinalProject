package com.credibanco.migracion.portal.backend.models.dto;

import java.util.List;

public class TerminalGenericaRequestDto {
	private String tipoServicio;
	private String codigoOriginador;
	private String codigoComercio;
	private List<SolicitudTerminalDto> solicitudTerminales;
	
	public TerminalGenericaRequestDto() {
		super();
	}

	public TerminalGenericaRequestDto(String tipoServicio, String codigoOriginador, String codigoComercio,
			List<SolicitudTerminalDto> solicitudTerminales) {
		super();
		this.tipoServicio = tipoServicio;
		this.codigoOriginador = codigoOriginador;
		this.codigoComercio = codigoComercio;
		this.solicitudTerminales = solicitudTerminales;
	}

	public String getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(String tipoServicio) {
		this.tipoServicio = tipoServicio;
	}

	public String getCodigoOriginador() {
		return codigoOriginador;
	}

	public void setCodigoOriginador(String codigoOriginador) {
		this.codigoOriginador = codigoOriginador;
	}

	public String getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public List<SolicitudTerminalDto> getSolicitudTerminales() {
		return solicitudTerminales;
	}

	public void setSolicitudTerminales(List<SolicitudTerminalDto> solicitudTerminales) {
		this.solicitudTerminales = solicitudTerminales;
	}

	@Override
	public String toString() {
		return "TerminalGenericaRequestDto [tipoServicio=" + tipoServicio + ", codigoOriginador=" + codigoOriginador
				+ ", codigoComercio=" + codigoComercio + ", solicitudTerminales=" + solicitudTerminales + "]";
	}

}
