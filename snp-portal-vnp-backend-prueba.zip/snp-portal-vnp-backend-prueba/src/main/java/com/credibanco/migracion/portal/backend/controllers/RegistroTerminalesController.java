package com.credibanco.migracion.portal.backend.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.CSVTerminalesColumns;
import com.credibanco.migracion.portal.backend.models.dto.PasarelaDTO;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalRequest;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalResponse;
import com.credibanco.migracion.portal.backend.services.ILogService;
import com.credibanco.migracion.portal.backend.services.IRegistroTerminalesService;
import com.credibanco.migracion.portal.backend.services.PasarelasService;
import com.credibanco.migracion.portal.backend.utils.JWTUtil;
import com.credibanco.migracion.portal.backend.utils.WriteCsvToResponse;

@RestController
@RequestMapping("/registro-terminales")
@CrossOrigin(origins = "*")
public class RegistroTerminalesController {
	
	@Autowired
	private IRegistroTerminalesService registroTerminalesService;
	
	@Autowired
	private ILogService logService;
	
	private PasarelasService pasarelasService;
	
	@Autowired
	public RegistroTerminalesController(PasarelasService pasarelasService) {
		this.pasarelasService = pasarelasService;

	}
	
	@GetMapping
	public List<RegistroTerminalResponse> obtenerTerminales(@RequestHeader(name = "Authorization") String token, HttpServletRequest request) throws Exception{
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Terminales-pasarelas", "Consulta", request.getRemoteAddr(), null, null));
		return registroTerminalesService.obtenerTerminales();
	}
	
	@GetMapping("/plantilla")
	public void obtenerPlantillaTerminales(	HttpServletRequest request,
											HttpServletResponse response) throws IOException, PortalBackendException{
		List<PasarelaDTO> pasarelas = pasarelasService.getPasarelas();
		List<CSVTerminalesColumns> terminales = new ArrayList<>();
		pasarelas.forEach(pasarela -> terminales.add(new CSVTerminalesColumns(1L, pasarela.getUsuario())));
		WriteCsvToResponse.writeTerminales(response.getWriter(), terminales);
	}

	@PostMapping
	public void registrarTerminales(@RequestHeader(name = "Authorization") String token, @RequestBody List<RegistroTerminalRequest> terminales,
									HttpServletRequest request,
									HttpServletResponse response) throws Exception{
		String username = JWTUtil.getPreferredUsernameFromPayloadJWT(token);
		logService.saveLog(logService.construirObjetoLog(username,"Terminales-pasarelas", "Creación", request.getRemoteAddr(), terminales.stream().map(RegistroTerminalRequest::getNumeroTerminal).collect(Collectors.toList()).toString(), null));
		WriteCsvToResponse.writeResponseTerminales(response.getWriter(), registroTerminalesService.registrarTerminales(terminales, username)); 
	}
	
	@PutMapping
	public RegistroTerminalResponse actualizarTerminal(	@RequestHeader(name = "Authorization") String token, 
														@RequestBody RegistroTerminalRequest terminal,
														HttpServletRequest request,
														HttpServletResponse response) throws Exception {
		String username = JWTUtil.getPreferredUsernameFromPayloadJWT(token);
		terminal.setUsuarioModificacion(username);
		logService.saveLog(logService.construirObjetoLog(username,"Terminales-pasarelas", "Edición", request.getRemoteAddr(), terminal.toString(), null));
		return registroTerminalesService.actualizarTerminal(terminal);
	}
}
