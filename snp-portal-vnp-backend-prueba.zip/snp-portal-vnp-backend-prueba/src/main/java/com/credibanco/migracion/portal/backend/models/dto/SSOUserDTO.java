package com.credibanco.migracion.portal.backend.models.dto;

import java.util.List;

public class SSOUserDTO {
	private String id;
	private Long createdTimestamp;
    private String username;
    private Boolean enabled;
    private Boolean totp;
    private Boolean emailVerified;
    private String email;
    private List<String> disableableCredentialTypes;
    private List<String> requiredActions;
    private Integer notBefore;
    
	public SSOUserDTO() {
		super();
	}

	public SSOUserDTO(String id, Long createdTimestamp, String username, Boolean enabled, Boolean totp,
			Boolean emailVerified, String email, List<String> disableableCredentialTypes, List<String> requiredActions,
			Integer notBefore) {
		super();
		this.id = id;
		this.createdTimestamp = createdTimestamp;
		this.username = username;
		this.enabled = enabled;
		this.totp = totp;
		this.emailVerified = emailVerified;
		this.email = email;
		this.disableableCredentialTypes = disableableCredentialTypes;
		this.requiredActions = requiredActions;
		this.notBefore = notBefore;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Long createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public Boolean getTotp() {
		return totp;
	}

	public void setTotp(Boolean totp) {
		this.totp = totp;
	}

	public Boolean getEmailVerified() {
		return emailVerified;
	}

	public void setEmailVerified(Boolean emailVerified) {
		this.emailVerified = emailVerified;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<String> getDisableableCredentialTypes() {
		return disableableCredentialTypes;
	}

	public void setDisableableCredentialTypes(List<String> disableableCredentialTypes) {
		this.disableableCredentialTypes = disableableCredentialTypes;
	}

	public List<String> getRequiredActions() {
		return requiredActions;
	}

	public void setRequiredActions(List<String> requiredActions) {
		this.requiredActions = requiredActions;
	}

	public Integer getNotBefore() {
		return notBefore;
	}

	public void setNotBefore(Integer notBefore) {
		this.notBefore = notBefore;
	}

	@Override
	public String toString() {
		return "SSOUserDTO [id=" + id + ", createdTimestamp=" + createdTimestamp + ", username=" + username
				+ ", enabled=" + enabled + ", totp=" + totp + ", emailVerified=" + emailVerified + ", email=" + email
				+ ", disableableCredentialTypes=" + disableableCredentialTypes + ", requiredActions=" + requiredActions
				+ ", notBefore=" + notBefore + "]";
	}
    
}
