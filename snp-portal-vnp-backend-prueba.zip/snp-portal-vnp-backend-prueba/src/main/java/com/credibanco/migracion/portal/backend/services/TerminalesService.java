package com.credibanco.migracion.portal.backend.services;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.credibanco.migracion.portal.backend.clients.SVConsultaComerciosTerminales;
import com.credibanco.migracion.portal.backend.clients.SVTerminalGenericaClient;
import com.credibanco.migracion.portal.backend.exceptions.ErrorDetails;
import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.exceptions.TransactionException;
import com.credibanco.migracion.portal.backend.models.dto.ConsultaTerminalRequest;
import com.credibanco.migracion.portal.backend.models.dto.ConsultaTerminalResponse;
import com.credibanco.migracion.portal.backend.models.dto.CrearTerminalRequestDto;
import com.credibanco.migracion.portal.backend.models.dto.CrearTerminalResponseDto;
import com.credibanco.migracion.portal.backend.models.dto.DesactivarTerminalResponseDto;
import com.credibanco.migracion.portal.backend.models.dto.DireccionInstalacion;
import com.credibanco.migracion.portal.backend.models.dto.SolicitudTerminales;
import com.credibanco.migracion.portal.backend.models.dto.Terminal;
import com.credibanco.migracion.portal.backend.models.dto.TerminalData;
import com.credibanco.migracion.portal.backend.models.dto.TerminalGenericaObjectDto;
import com.credibanco.migracion.portal.backend.models.dto.TerminalGenericaResponseDto;

@Service
public class TerminalesService implements ITerminalesService {

	private static final Logger LOGGER = LoggerFactory.getLogger(TerminalesService.class);

	private SVTerminalGenericaClient svTerminalGenericaClient;
	
	private SVConsultaComerciosTerminales svConsultaComerciosTerminales;

	@Autowired
	public TerminalesService(	SVTerminalGenericaClient svTerminalGenericaClient,
								SVConsultaComerciosTerminales svConsultaComerciosTerminales) {
		this.svTerminalGenericaClient = svTerminalGenericaClient;
		this.svConsultaComerciosTerminales = svConsultaComerciosTerminales;
	}

	@Override
	public CrearTerminalResponseDto crearTerminal(CrearTerminalRequestDto crearTerminalRequestDto)
			throws PortalBackendException {
		LOGGER.info("crearTerminal(): creando objeto request terminalGenerico");
		Terminal terminalGenericaRequestDto = createTerminalGenericaDto(crearTerminalRequestDto);
		LOGGER.info("crearTerminal(): consumiendo client terminal generico");
		TerminalGenericaResponseDto terminalGenericaResponse = svTerminalGenericaClient.postTerminalGenerica(terminalGenericaRequestDto);
		
		LOGGER.info("crearTerminal(): creando objeto de respuesta");
		CrearTerminalResponseDto result = createCreatTerminalResponseDto(terminalGenericaResponse);
		return result;
	}

	@Override
	public CrearTerminalResponseDto modificarTerminal(CrearTerminalRequestDto crearTerminalRequestDto, Terminal terminalDataAntes)
			throws PortalBackendException, ParserConfigurationException {
		Terminal terminalGenericaRequestDto = createTerminalGenericaModificarDto(crearTerminalRequestDto, terminalDataAntes);
		LOGGER.info("modificarTerminal(): objeto a modificar: {}", terminalGenericaRequestDto);
		TerminalGenericaResponseDto terminalGenericaResponse = svTerminalGenericaClient.postTerminalGenerica(terminalGenericaRequestDto);
		LOGGER.info("modificarTerminal(): creando objeto de respuesta");
		CrearTerminalResponseDto result = createCreatTerminalResponseDto(terminalGenericaResponse);
		return result;
	}

	@Override
	public DesactivarTerminalResponseDto desactivarTerminal(String idTerminal, String cu)
			throws PortalBackendException {
		Terminal terminalGenericaRequestDto = createTerminalGenericaEliminarDto(idTerminal, cu);
		LOGGER.info("crearTerminal(): consumiendo client terminal generico");
		TerminalGenericaResponseDto terminalGenericaResponse = svTerminalGenericaClient.postTerminalGenerica(terminalGenericaRequestDto);
		LOGGER.info("crearTerminal(): creando objeto de respuesta");
		DesactivarTerminalResponseDto result = new DesactivarTerminalResponseDto(terminalGenericaResponse.getCode(),
				idTerminal, cu);
		return result;
	}
	
	@Override
	public TerminalData consultarTerminal(String idTerminal) throws ParserConfigurationException, PortalBackendException {
		ConsultaTerminalRequest consultaTerminalRequest = new ConsultaTerminalRequest();
		consultaTerminalRequest.setOperation("unicaTerminal");
		consultaTerminalRequest.setCode(idTerminal);
		ConsultaTerminalResponse response = svConsultaComerciosTerminales.consultaUnicaTerminal(consultaTerminalRequest);
		if(response.getResponse().equals("<applications></applications>"))
			throw new PortalBackendException(new ErrorDetails(new Date(), "99", "Error en la respuesta del servicio de consulta"));
		Document document = convertStringToXMLDocument( response.getResponse() );
		TerminalData terminal = xmlToTerminalDtoMapper( document );
        LOGGER.info("Terminal data: " + terminal.toString() );
        return terminal;
	}
	
	private TerminalData xmlToTerminalDtoMapper(Document document) {
		TerminalData terminalData = new TerminalData();
		terminalData.setIndicadorIva(document.getElementsByTagName("cst_terminal_iva").item(0)==null?null:document.getElementsByTagName("cst_terminal_iva").item(0).getTextContent());
		terminalData.setIndicadorIca(document.getElementsByTagName("cst_terminal_iac").item(0)==null?null:document.getElementsByTagName("cst_terminal_iac").item(0).getTextContent());
		terminalData.setIndicadorReferencia(document.getElementsByTagName("cst_terminal_additional_info").item(0)==null?null:document.getElementsByTagName("cst_terminal_additional_info").item(0).getTextContent());
		terminalData.setIndicadorPropina(document.getElementsByTagName("attribute_value_num").item(0)==null?null:document.getElementsByTagName("attribute_value_num").item(0).getTextContent());
		terminalData.setTerminalId(document.getElementsByTagName("terminal_number").item(0)==null?null:document.getElementsByTagName("terminal_number").item(0).getTextContent());
		terminalData.setTerminalState(document.getElementsByTagName("terminal_status").item(0)==null?null:document.getElementsByTagName("terminal_status").item(0).getTextContent());
		terminalData.setUniqueCode(document.getElementsByTagName("merchant_number").item(0)==null?null:document.getElementsByTagName("merchant_number").item(0).getTextContent());
		NodeList nodeListServices = document.getElementsByTagName("attribute_char");
		terminalData.setServicios(this.obtenerServicios(nodeListServices));
		return terminalData;
	}

	private ArrayList<String> obtenerServicios(NodeList nodeListServices) {
		ArrayList<String> servicios = new ArrayList<>();
		for(int i = 0; i < nodeListServices.getLength(); i++) {
			String nodeValue = nodeListServices.item(i).getAttributes().getNamedItem("value").getNodeValue();
			if(nodeValue.equals("50000376")) {
				NodeList listService = nodeListServices.item(i).getChildNodes();
				for(int j = 0; j<listService.getLength(); j++) 
					if(listService.item(j).getNodeName().equals("attribute_value_char"))
						servicios.add(nodeListServices.item(i).getChildNodes().item(j).getTextContent());
			}
		}
		return servicios;
	}
	
	

	private static Document convertStringToXMLDocument(String xmlString) throws ParserConfigurationException 
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        DocumentBuilder builder = null;
        try
        {
            builder = factory.newDocumentBuilder();
            return builder.parse(new InputSource(new StringReader(xmlString)));
        } 
        catch (Exception e) 
        {
        	LOGGER.error("Error en la conversión XML to JSON.");
            throw new TransactionException("Error en la conversión XML to JSON.");
        }
    }

	private Terminal createTerminalGenericaEliminarDto(String idTerminal, String cu) {
		Terminal result = new Terminal();
		result.setCodigoComercio(cu);
		result.setUsuarioOriginador("3");
		result.setTipoServicio("02");
		List<SolicitudTerminales> solicitudTerminalDtoList = new ArrayList<>();
		SolicitudTerminales solicitudTerminal = createSolicitudTerminalEliminar(idTerminal);
		solicitudTerminalDtoList.add(solicitudTerminal);
		result.setSolicitudTerminales(solicitudTerminalDtoList);
		return result;
	}

	private SolicitudTerminales createSolicitudTerminalEliminar(String idTerminal) {
		SolicitudTerminales result = new SolicitudTerminales();

		DireccionInstalacion terminalGenericaDireccion = null;
//		terminalGenericaDireccion.setApartamentoOficina(null);
//		terminalGenericaDireccion.setCodigoPostal(null);
//		terminalGenericaDireccion.setCodigoRegion(direccionTerminal.getCodigoRegion());
//		terminalGenericaDireccion.setDireccionNumero(direccionTerminal.getDireccionNumero());
//		terminalGenericaDireccion.setLatitud(direccionTerminal.getLatitud());
//		terminalGenericaDireccion.setLongitud(direccionTerminal.getLongitud());
//		terminalGenericaDireccion.setPais(direccionTerminal.getPais());
		// terminalGenericaDireccion

		result.setCantidadTerminales(null);
//		result.setCodigoArrendamiento(nuevoTerminalDto.getCodigoArrendamiento());
		result.setDireccionDeInstalacion(terminalGenericaDireccion);
//		result.setDueno(nuevoTerminalDto.getDueno());
		result.setEstadoTerminal("TRMS0009");
//		result.setFechaDeseada(nuevoTerminalDto.getFechaDeseada());
//		result.setFechaRetiroProgramado(nuevoTerminalDto.getFechaRetiroProgramado());
//		result.setIdServicio(nuevoTerminalDto.getServiciosId());
		List<String> idsTerminal = new ArrayList<>();
		idsTerminal.add(idTerminal);
		result.setIdTerminales(idsTerminal);
//		result.setIndicadorCvv2(null);
//		result.setIndicadorDeReferencia(null);
//		result.setIndicadorIca(nuevoTerminalDto.getIndicadorIca());
//		result.setIndicadorIva(nuevoTerminalDto.getIndicadorIva());
//		result.setIndicadorPropina(nuevoTerminalDto.getIndicadorPropina());
//		result.setMarcaDispositivo(nuevoTerminalDto.getMarcaDispositivo());
//		result.setNumeroCaja(nuevoTerminalDto.getNumeroCaja());
//		result.setNumeroTerminalFisicaMulticomercio(nuevoTerminalDto.getNumeroTerminalFisicaMulticomercio());
//		result.setObservaciones(nuevoTerminalDto.getObservaciones());
//		result.setRazonEstado("TRMS0009");
//		result.setSello(nuevoTerminalDto.getSello());
//		result.setSerial(nuevoTerminalDto.getSerial());
//		result.setTipoComunicacion(nuevoTerminalDto.getTipoComunicacion());
//		result.setTipoDispositivo(nuevoTerminalDto.getTipoDispositivo());
//		result.setTipoIntegracionTEF(nuevoTerminalDto.getTipoIntegracionTEF());

		return result;
	}

	private CrearTerminalResponseDto createCreatTerminalResponseDto(
			TerminalGenericaResponseDto terminalGenericaResponse) {
		CrearTerminalResponseDto result = new CrearTerminalResponseDto();
		result.setCodigoRespuesta(terminalGenericaResponse.getCode());
		result.setMensaje(terminalGenericaResponse.getMessage());
		CrearTerminalRequestDto objetoResult = null;
		if(terminalGenericaResponse.getObject() != null) {
			objetoResult = createObjectResponse(terminalGenericaResponse.getObject());
		}
		result.setObjeto(objetoResult);

		return result;
	}

	private CrearTerminalRequestDto createObjectResponse(TerminalGenericaObjectDto object) {
		CrearTerminalRequestDto result = new CrearTerminalRequestDto();
		result.setCodigoComercio(object.getCodigoComercio());
		result.setCodigoOriginador(object.getCodigoOriginador());
		SolicitudTerminales solicitudTerminalDto = new SolicitudTerminales();
		SolicitudTerminales nuevoTerminalDto = new SolicitudTerminales();
		if(object.getSolicitudTerminales() != null && object.getSolicitudTerminales().size() > 0) {
			solicitudTerminalDto = object.getSolicitudTerminales().get(0);
			nuevoTerminalDto = createNuevoTerminalDto(solicitudTerminalDto);
		}
		result.setTerminal(nuevoTerminalDto);
		return result;
	}

	private SolicitudTerminales createNuevoTerminalDto(SolicitudTerminales solicitudTerminalDto) {
		SolicitudTerminales result = new SolicitudTerminales();
		result.setCodigoArrendamiento(solicitudTerminalDto.getCodigoArrendamiento());
		result.setDireccionDeInstalacion(null);
		result.setDueno(solicitudTerminalDto.getDueno());
		result.setEstadoTerminal(solicitudTerminalDto.getEstadoTerminal());
		result.setFechaRetiroProgramado(solicitudTerminalDto.getFechaRetiroProgramado());
		result.setIndicadorIac(solicitudTerminalDto.getIndicadorIac());
		result.setIndicadorIva(solicitudTerminalDto.getIndicadorIva());
		result.setIndicadorPropina(solicitudTerminalDto.getIndicadorPropina());
		result.setMarcaDispositivo(solicitudTerminalDto.getMarcaDispositivo());
		result.setNumeroCaja(solicitudTerminalDto.getNumeroCaja());
		result.setObservaciones(solicitudTerminalDto.getObservaciones());
		result.setSello(solicitudTerminalDto.getSello());
		result.setSerial(solicitudTerminalDto.getSerial());
		result.setIdServicio(solicitudTerminalDto.getIdServicio());
		result.setTipoComunicacion(solicitudTerminalDto.getTipoComunicacion());
		result.setTipoDispositivo(solicitudTerminalDto.getTipoDispositivo());
		result.setTipoIntegracionTEF(solicitudTerminalDto.getTipoIntegracionTEF());
		result.setIdTerminales(null);
		if(solicitudTerminalDto.getIdTerminales() != null && solicitudTerminalDto.getIdTerminales().size() > 0) {
			result.setIdTerminales(solicitudTerminalDto.getIdTerminales());
		}
		return result;
	}

	private Terminal createTerminalGenericaModificarDto(CrearTerminalRequestDto crearTerminalRequestDto, Terminal terminalDataAntes) {
		terminalDataAntes.setCodigoComercio(crearTerminalRequestDto.getCodigoComercio());
		terminalDataAntes.setUsuarioOriginador(crearTerminalRequestDto.getCodigoOriginador());
		terminalDataAntes.setTipoServicio("04");
		List<SolicitudTerminales> solicitudTerminalDtoList = new ArrayList<>();
		SolicitudTerminales solicitudTerminal = terminalDataAntes.getSolicitudTerminales().get(0);
		solicitudTerminal.setIndicadorIac(crearTerminalRequestDto.getTerminal().getIndicadorIac());
		solicitudTerminal.setIndicadorIva(crearTerminalRequestDto.getTerminal().getIndicadorIva());
		solicitudTerminal.setIdServicio(crearTerminalRequestDto.getTerminal().getIdServicio());
		solicitudTerminalDtoList.add(solicitudTerminal);
		terminalDataAntes.setSolicitudTerminales(solicitudTerminalDtoList);
		return terminalDataAntes;
	}

	private Terminal createTerminalGenericaDto(CrearTerminalRequestDto crearTerminalRequestDto) {
		Terminal result = new Terminal();
		result.setCodigoComercio(crearTerminalRequestDto.getCodigoComercio());
		result.setUsuarioOriginador(crearTerminalRequestDto.getCodigoOriginador());
		result.setTipoServicio("01");
		List<SolicitudTerminales> solicitudTerminalDtoList = new ArrayList<>();
		solicitudTerminalDtoList.add(crearTerminalRequestDto.getTerminal());
		result.setSolicitudTerminales(solicitudTerminalDtoList);
		return result;
	}

	@Override
	public Terminal consultaTerminalModificacion(String idTerminal) throws PortalBackendException, ParserConfigurationException {
		ConsultaTerminalRequest consultaTerminalRequest = new ConsultaTerminalRequest();
		consultaTerminalRequest.setOperation("unicaTerminal");
		consultaTerminalRequest.setCode(String.format("%8s", idTerminal).replace(' ','0'));
		ConsultaTerminalResponse response = svConsultaComerciosTerminales.consultaUnicaTerminal(consultaTerminalRequest);
		if(response.getResponse().equals("<applications></applications>"))
			throw new PortalBackendException(new ErrorDetails(new Date(), "99", "Error en la respuesta"));
		Document document = convertStringToXMLDocument( response.getResponse() );
		LOGGER.info("Document"+ response.getResponse());
		Terminal terminal = xmlToTerminalAllAtributesMapper( document );
	    LOGGER.info("Terminal data: " + terminal.toString() );
    return terminal;
	}
	
	private Terminal xmlToTerminalAllAtributesMapper(Document document) {
		
		SolicitudTerminales terminalDataObject = new SolicitudTerminales();
		
		terminalDataObject.setCantidadTerminales("1");
		terminalDataObject.setIdTerminales(Arrays.asList(document.getElementsByTagName("terminal_number").item(0)==null?null:document.getElementsByTagName("terminal_number").item(0).getTextContent()));
		terminalDataObject.setDueno(document.getElementsByTagName("cst_terminal_owner").item(0)==null?null:document.getElementsByTagName("cst_terminal_owner").item(0).getTextContent());
		terminalDataObject.setTipoDispositivo(document.getElementsByTagName("terminal_type").item(0)==null?null:document.getElementsByTagName("terminal_type").item(0).getTextContent());
		terminalDataObject.setTipoComunicacion(document.getElementsByTagName("cst_terminal_communication_type").item(0)==null?null:document.getElementsByTagName("cst_terminal_communication_type").item(0).getTextContent());
		terminalDataObject.setTipoIntegracionTEF(document.getElementsByTagName("cst_terminal_box_integration").item(0)==null?null:document.getElementsByTagName("cst_terminal_box_integration").item(0).getTextContent());
		terminalDataObject.setMarcaDispositivo(document.getElementsByTagName("cst_terminal_brand").item(0)==null?"":document.getElementsByTagName("cst_terminal_brand").item(0).getTextContent());
		terminalDataObject.setIndicadorIac(document.getElementsByTagName("cst_terminal_iac").item(0)==null?"0":document.getElementsByTagName("cst_terminal_iac").item(0).getTextContent());
		terminalDataObject.setIndicadorIva(document.getElementsByTagName("cst_terminal_iva").item(0)==null?"0":document.getElementsByTagName("cst_terminal_iva").item(0).getTextContent());
		NodeList nodeListServices = document.getElementsByTagName("attribute_char");
		LOGGER.info("nodeListServices: {}", nodeListServices );
		terminalDataObject.setIdServicio(this.obtenerServicios(nodeListServices));
		terminalDataObject.setIndicadorPropina(document.getElementsByTagName("attribute_value_num").item(0)==null?null:(int)Double.parseDouble(document.getElementsByTagName("attribute_value_num").item(0).getTextContent()));	
		terminalDataObject.setIndicadorDeReferencia(document.getElementsByTagName("cst_terminal_additional_info").item(0)==null?null:document.getElementsByTagName("cst_terminal_additional_info").item(0).getTextContent());
		terminalDataObject.setIndicadorCvv2(this.obtenerValorCvv2(nodeListServices));
		
		DireccionInstalacion direccionInstalacion = new DireccionInstalacion();
		direccionInstalacion.setPais(document.getElementsByTagName("country").item(0)==null?null:document.getElementsByTagName("country").item(0).getTextContent());
		direccionInstalacion.setDireccionNumero(document.getElementsByTagName("home").item(0)==null?"170":document.getElementsByTagName("country").item(0).getTextContent());
		direccionInstalacion.setApartamentoOficina(document.getElementsByTagName("apartment").item(0)==null?null:document.getElementsByTagName("apartment").item(0).getTextContent());
		direccionInstalacion.setCodigoPostal(document.getElementsByTagName("postal_code").item(0)==null?"":document.getElementsByTagName("postal_code").item(0).getTextContent());
		direccionInstalacion.setCodigoRegion(document.getElementsByTagName("region_code").item(0)==null?"":document.getElementsByTagName("region_code").item(0).getTextContent());
		direccionInstalacion.setLatitud(document.getElementsByTagName("latitude").item(0)==null?"0":document.getElementsByTagName("latitude").item(0).getTextContent());
		direccionInstalacion.setLongitud(document.getElementsByTagName("longitude").item(0)==null?"0":document.getElementsByTagName("longitude").item(0).getTextContent());
		terminalDataObject.setDireccionDeInstalacion(direccionInstalacion);
		
		terminalDataObject.setEstadoTerminal(document.getElementsByTagName("terminal_status").item(0)==null?null:document.getElementsByTagName("terminal_status").item(0).getTextContent());
		terminalDataObject.setRazonEstado(document.getElementsByTagName("cst_terminal_block_reason").item(0)==null?"":document.getElementsByTagName("cst_terminal_block_reason").item(0).getTextContent());
		terminalDataObject.setSerial(document.getElementsByTagName("plastic_number").item(0)==null?"":document.getElementsByTagName("plastic_number").item(0).getTextContent());
		terminalDataObject.setSello(document.getElementsByTagName("cst_terminal_terminal_seal").item(0)==null?"":document.getElementsByTagName("cst_terminal_terminal_seal").item(0).getTextContent());
		terminalDataObject.setNumeroCaja(document.getElementsByTagName("cst_terminal_box_number").item(0)==null?"":document.getElementsByTagName("cst_terminal_box_number").item(0).getTextContent());
		terminalDataObject.setCodigoArrendamiento(document.getElementsByTagName("cst_terminal_renting_code").item(0)==null?"":document.getElementsByTagName("cst_terminal_renting_code").item(0).getTextContent());
		terminalDataObject.setFechaRetiroProgramado(document.getElementsByTagName("cst_terminal_retirement_date").item(0)==null?"":document.getElementsByTagName("cst_terminal_retirement_date").item(0).getTextContent());
		terminalDataObject.setObservaciones(document.getElementsByTagName("cst_terminal_desc").item(0)==null?"":document.getElementsByTagName("cst_terminal_desc").item(0).getTextContent());
		
		Terminal terminalData = new Terminal();
		ArrayList<SolicitudTerminales> solicitudTerminalesArray = new ArrayList<>();
		solicitudTerminalesArray.add(terminalDataObject);
		terminalData.setSolicitudTerminales(solicitudTerminalesArray);
		return terminalData;
	}
	
	private String obtenerValorCvv2(NodeList nodeListServices) {
		String indicadorCvv2 = "";
		for(int i = 0; i < nodeListServices.getLength(); i++) {
			String nodeValue = nodeListServices.item(i).getAttributes().getNamedItem("value").getNodeValue();
			if(nodeValue.equals("50000221")) {
				NodeList listService = nodeListServices.item(i).getChildNodes();
				for(int j = 0; j<listService.getLength(); j++) 
					if(listService.item(j).getNodeName().equals("limit_sum_value"))
						indicadorCvv2 = nodeListServices.item(i).getChildNodes().item(j).getTextContent();
			}
		}
		return indicadorCvv2;
	}



}
