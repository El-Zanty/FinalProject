package com.credibanco.migracion.portal.backend.models.dto;

public class DesactivarTerminalResponseDto {
	private String codigoRespuesta;
	private String terminal;
	private String cu;
	
	public DesactivarTerminalResponseDto() {
		super();
	}

	public DesactivarTerminalResponseDto(String codigoRespuesta, String terminal, String cu) {
		super();
		this.codigoRespuesta = codigoRespuesta;
		this.terminal = terminal;
		this.cu = cu;
	}

	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}

	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}

	public String getTerminal() {
		return terminal;
	}

	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}

	public String getCu() {
		return cu;
	}

	public void setCu(String cu) {
		this.cu = cu;
	}

	@Override
	public String toString() {
		return "DesactivarTerminalResponseDto [codigoRespuesta=" + codigoRespuesta + ", terminal=" + terminal + ", cu="
				+ cu + "]";
	}
	
}
