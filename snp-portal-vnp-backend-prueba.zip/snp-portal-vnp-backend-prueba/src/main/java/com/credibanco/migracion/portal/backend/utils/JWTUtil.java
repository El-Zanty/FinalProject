package com.credibanco.migracion.portal.backend.utils;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JWTUtil {
	
	private static final Logger LOG = LoggerFactory.getLogger(JWTUtil.class);
	
	@Value("${ErrorDecodeJWT.token}")
	private static String errorDecodeJWTcode;
	
	public static String getPreferredUsernameFromPayloadJWT(String token) throws Exception {
		String[] tokenSplit = token.split("\\.");
		Base64.Decoder decoder = Base64.getDecoder();
		String payload = new String(decoder.decode(tokenSplit[1]));
		Map<String, String> payloadMap;
		String preferredUsername = "";
		try {
			payloadMap = new ObjectMapper().readValue(payload, HashMap.class);
			preferredUsername = payloadMap.get("preferred_username");
		} catch (IOException e) {
			LOG.error("Error decode JWT: ", e);
			throw new Exception(errorDecodeJWTcode);
		}
		return preferredUsername;
	}

}
