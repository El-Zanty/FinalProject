package com.credibanco.migracion.portal.backend.configuration;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
@Order(Ordered.LOWEST_PRECEDENCE)
public class CorsFilter extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		 String requestHost = request.getHeader("Referer");

		 //response.addHeader("Access-Control-Allow-Origin", "");

         if (request.getHeader("Access-Control-Request-Method") != null
                 && "OPTIONS".equals(request.getMethod())) {
             // CORS "pre-flight" request
             response.addHeader("Access-Control-Allow-Methods",

                     "GET, POST, DELETE, PUT, OPTIONS");

             response.addHeader("Access-Control-Allow-Headers",
                     "X-Requested-With,Origin,Content-Type, Accept");
             response.addHeader("Access-Control-Allow-Credentials", "true");
         }
         System.out.println("entro===============================================");
         filterChain.doFilter(request, response);
		
	}
	
}

