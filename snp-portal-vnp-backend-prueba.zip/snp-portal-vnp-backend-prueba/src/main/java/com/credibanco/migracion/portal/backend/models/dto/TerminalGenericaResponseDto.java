package com.credibanco.migracion.portal.backend.models.dto;

public class TerminalGenericaResponseDto {
	private String code;
	private String message;
	private TerminalGenericaObjectDto object;
	
	public TerminalGenericaResponseDto() {
		super();
	}

	public TerminalGenericaResponseDto(String code, String message, TerminalGenericaObjectDto object) {
		super();
		this.code = code;
		this.message = message;
		this.object = object;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public TerminalGenericaObjectDto getObject() {
		return object;
	}

	public void setObject(TerminalGenericaObjectDto object) {
		this.object = object;
	}

	@Override
	public String toString() {
		return "TerminalGenericaResponseDto [code=" + code + ", message=" + message + ", object=" + object + "]";
	}
	
}
