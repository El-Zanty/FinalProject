package com.credibanco.migracion.portal.backend.models.dto;

public class CrearTerminalResponseDto {
	private String codigoRespuesta;
	private String mensaje;
	private CrearTerminalRequestDto objeto;
	
	public CrearTerminalResponseDto() {
		super();
	}
	
	public CrearTerminalResponseDto(String codigoRespuesta, String mensaje, CrearTerminalRequestDto objeto) {
		super();
		this.codigoRespuesta = codigoRespuesta;
		this.mensaje = mensaje;
		this.objeto = objeto;
	}
	
	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}
	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public CrearTerminalRequestDto getObjeto() {
		return objeto;
	}
	public void setObjeto(CrearTerminalRequestDto objeto) {
		this.objeto = objeto;
	}
	
	@Override
	public String toString() {
		return "CrearTerminalResponseDto [codigoRespuesta=" + codigoRespuesta + ", mensaje=" + mensaje + ", objeto="
				+ objeto + "]";
	}
	
}
