package com.credibanco.migracion.portal.backend.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.credibanco.migracion.portal.backend.exceptions.ErrorDetails;
import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.PasarelaDTO;
import com.credibanco.migracion.portal.backend.services.ILogService;
import com.credibanco.migracion.portal.backend.services.PasarelasService;
import com.credibanco.migracion.portal.backend.utils.JWTUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/pasarelas")
//Controlador del recurso pasarelas
public class PasarelasController {
	
	private PasarelasService pasarelasService;
	
	@Autowired
	private ILogService logService;
	
	@Autowired
	public PasarelasController(PasarelasService pasarelasService) {
		this.pasarelasService = pasarelasService;
	}


	@GetMapping
	@ApiOperation(value = "Obtener pasarelas", notes = "obtener pasarelas", response = PasarelaDTO[].class, produces = "application/json")
	@ApiResponses({	@ApiResponse(code = 200, message = "Ejecución exitosa"),
					@ApiResponse(code = 401, message = "Unauthorized"),
					@ApiResponse(code = 403, message = "Acceso no permitido"),
					@ApiResponse(code = 500, message = "Error interno", response=ErrorDetails.class)})
	//Recurso pasarelas
	public ResponseEntity<?> getPasarelas(@RequestHeader(name = "Authorization") String token, HttpServletRequest request) throws Exception {
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Pasarelas", "Consulta", request.getRemoteAddr(), null, null));
		List<PasarelaDTO> pasarelas;
		try {
			pasarelas = pasarelasService.getPasarelas();
			return new ResponseEntity <List<PasarelaDTO> >(pasarelas, HttpStatus.OK);
		} catch (PortalBackendException e) {
			return new ResponseEntity<>(e.getError(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
