package com.credibanco.migracion.portal.backend.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiciosAdicionalesController {
	
	@GetMapping("/seguridad-herramientas")
	public String herramientasSeguridad() {
		return "Servicios de herramientas de seguridad.";
	}
	
	@GetMapping("/data-dashboard")
	public String obtenerDatosDashBoard() {
		return "Servicio para obtener data dashboard.";
	}

}
