package com.credibanco.migracion.portal.backend.models.dto;

import java.util.ArrayList;
import java.util.List;

import com.credibanco.migracion.transacciones.dto.Transaction;

public class ResponseTransaction {
	
	private List<Transaction> listaTransacciones;

	public ResponseTransaction() {
		this.listaTransacciones = new ArrayList<>();
	}

	public List<Transaction> getListaTransacciones() {
		return listaTransacciones;
	}

	public void setListaTransacciones(List<Transaction> listaTransacciones) {
		this.listaTransacciones = listaTransacciones;
	}
	
	
}
