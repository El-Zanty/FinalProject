package com.credibanco.migracion.portal.backend.models.dto;

public class DireccionInstalacion {
	private String pais;
	private String direccionNumero;
	private String apartamentoOficina;
	private String codigoPostal;
	private String codigoRegion;
	private String latitud;
	private String longitud;

	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public String getDireccionNumero() {
		return direccionNumero;
	}
	public void setDireccionNumero(String direccionNumero) {
		this.direccionNumero = direccionNumero;
	}
	public String getApartamentoOficina() {
		return apartamentoOficina;
	}
	public void setApartamentoOficina(String apartamentoOficina) {
		this.apartamentoOficina = apartamentoOficina;
	}
	public String getCodigoPostal() {
		return codigoPostal;
	}
	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}
	public String getCodigoRegion() {
		return codigoRegion;
	}
	public void setCodigoRegion(String codigoRegion) {
		this.codigoRegion = codigoRegion;
	}
	public String getLatitud() {
		return latitud;
	}
	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}
	public String getLongitud() {
		return longitud;
	}
	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}
	@Override
	public String toString() {
		return "DireccionInstalacion [pais=" + pais + ", direccionNumero=" + direccionNumero + ", apartamentoOficina="
				+ apartamentoOficina + ", codigoPostal=" + codigoPostal + ", codigoRegion=" + codigoRegion
				+ ", latitud=" + latitud + ", longitud=" + longitud + "]";
	}
	
}
