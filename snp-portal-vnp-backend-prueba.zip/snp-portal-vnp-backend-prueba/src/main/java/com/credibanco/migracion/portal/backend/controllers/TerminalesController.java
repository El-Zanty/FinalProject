package com.credibanco.migracion.portal.backend.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.credibanco.migracion.portal.backend.models.dto.CrearTerminalRequestDto;
import com.credibanco.migracion.portal.backend.models.dto.CrearTerminalResponseDto;
import com.credibanco.migracion.portal.backend.models.dto.DesactivarTerminalResponseDto;
import com.credibanco.migracion.portal.backend.models.dto.OrquestadorPasarelasCreateRequestDTO;
import com.credibanco.migracion.portal.backend.models.dto.OrquestadorPasarelasDTO;
import com.credibanco.migracion.portal.backend.models.dto.OrquestadorPasarelasInactivarResponseDTO;
import com.credibanco.migracion.portal.backend.models.dto.OrquestadorPasarelasModificarRequestDTO;
import com.credibanco.migracion.portal.backend.models.dto.OrquestadorPasarelasModificarResponseDTO;
import com.credibanco.migracion.portal.backend.models.dto.Terminal;
import com.credibanco.migracion.portal.backend.models.dto.TerminalData;
import com.credibanco.migracion.portal.backend.services.ILogService;
import com.credibanco.migracion.portal.backend.services.IOrquestadorPasarelasService;
import com.credibanco.migracion.portal.backend.services.ITerminalesService;
import com.credibanco.migracion.portal.backend.utils.JWTUtil;

@RestController
@RequestMapping("/terminales")
@CrossOrigin(origins = "*")
public class TerminalesController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TerminalesController.class);
	
	private ITerminalesService terminalesService;

	private IOrquestadorPasarelasService orquestadorPasarelasService;
	
	@Autowired
	private ILogService logService;
	
	@Autowired
	public TerminalesController(ITerminalesService terminalesService, IOrquestadorPasarelasService orquestadorPasarelasService) {
		this.terminalesService = terminalesService;
		this.orquestadorPasarelasService = orquestadorPasarelasService;
	}
	
	@PostMapping
	public ResponseEntity<CrearTerminalResponseDto> crearTerminal(	@RequestHeader(name = "Authorization") String token,
																	@Valid @RequestBody(required=true) CrearTerminalRequestDto crearTerminalRequestDto, 
																	HttpServletRequest request) throws Exception {
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Terminales", "Crear", request.getRemoteAddr(), crearTerminalRequestDto.toString(), null));
		return new ResponseEntity<>(terminalesService.crearTerminal(crearTerminalRequestDto), HttpStatus.CREATED);
	}
	
	@PutMapping
	public ResponseEntity<CrearTerminalResponseDto> modificarTerminal(	@RequestHeader(name = "Authorization") String token,
																		@Valid @RequestBody(required=true) CrearTerminalRequestDto crearTerminalRequestDto, 
																		HttpServletRequest request) throws Exception {
		Terminal terminalDataAntes = terminalesService.consultaTerminalModificacion(crearTerminalRequestDto.getTerminal().getIdTerminales().get(0));
		LOGGER.info("Terminal: "  +  terminalDataAntes.toString());
		LOGGER.info("Terminal después: "  +  crearTerminalRequestDto.toString());
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Terminales", "Modificar", request.getRemoteAddr(), terminalDataAntes.toString(), crearTerminalRequestDto.toString()));
		return new ResponseEntity<>(terminalesService.modificarTerminal(crearTerminalRequestDto,terminalDataAntes), HttpStatus.OK);
	}

	@DeleteMapping(path="/{idTerminal}/comercios/{cu}")
	public ResponseEntity<DesactivarTerminalResponseDto> desactivarTerminal(@RequestHeader(name = "Authorization") String token,
																			@PathVariable("idTerminal") String idTerminal, 
																			@PathVariable("cu")String cu, 
																			HttpServletRequest request) throws Exception {
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Terminales", "Desactivar", request.getRemoteAddr(), "Id terminal: "+ idTerminal, null));
		return new ResponseEntity<>(terminalesService.desactivarTerminal(idTerminal, cu), HttpStatus.OK);
	}
	
	@GetMapping("/{idTerminal}")
	public ResponseEntity<TerminalData> consultarTerminal(	@RequestHeader(name = "Authorization") String token,
															@PathVariable("idTerminal") String idTerminal, 
															HttpServletRequest request) throws Exception{
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Terminales", "Consulta", request.getRemoteAddr(), "Id terminal: "+ idTerminal, null));
		return new ResponseEntity<>(terminalesService.consultarTerminal(idTerminal), HttpStatus.OK);
	}

	@PostMapping("/orquestador")
	public ResponseEntity<OrquestadorPasarelasDTO> crearTerminal(@RequestHeader(name = "Authorization") String token,
																 @RequestBody(required=true) OrquestadorPasarelasCreateRequestDTO orquestadorPasarelasCreateRequestDTO,
																 HttpServletRequest request) throws Exception {
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Terminales", "Crear", request.getRemoteAddr(), orquestadorPasarelasCreateRequestDTO.toString(), null));
		return new ResponseEntity<OrquestadorPasarelasDTO>(orquestadorPasarelasService.crearTerminal(orquestadorPasarelasCreateRequestDTO, JWTUtil.getPreferredUsernameFromPayloadJWT(token)), HttpStatus.CREATED);
	}

	@PutMapping("/orquestador")
	public ResponseEntity<OrquestadorPasarelasModificarResponseDTO> modificarTerminal(@RequestHeader(name = "Authorization") String token,
																					  @RequestBody(required=true) OrquestadorPasarelasModificarRequestDTO orquestadorPasarelasCreateRequestDTO,
																					  HttpServletRequest request) throws Exception {
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Terminales", "editar", request.getRemoteAddr(), orquestadorPasarelasCreateRequestDTO.toString(), null));
		return new ResponseEntity<OrquestadorPasarelasModificarResponseDTO>(orquestadorPasarelasService.modificarTerminal(orquestadorPasarelasCreateRequestDTO, JWTUtil.getPreferredUsernameFromPayloadJWT(token)), HttpStatus.OK);
	}

	@DeleteMapping("/orquestador")
	public ResponseEntity<OrquestadorPasarelasInactivarResponseDTO> inactivarTerminal(@RequestHeader(name = "Authorization") String token,
																					  HttpServletRequest request,
																					  @RequestParam String comercio, @RequestParam String terminal,
																					  @RequestParam String pasarela) throws Exception {
		logService.saveLog(logService.construirObjetoLog(JWTUtil.getPreferredUsernameFromPayloadJWT(token),"Terminales", "inhabilitar", request.getRemoteAddr(),"no Body", null));
		return new ResponseEntity<OrquestadorPasarelasInactivarResponseDTO>(orquestadorPasarelasService.inactivarTerminal(comercio, terminal, pasarela, JWTUtil.getPreferredUsernameFromPayloadJWT(token)), HttpStatus.OK);
	}

}
