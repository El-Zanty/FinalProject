package com.credibanco.migracion.portal.backend.services;

import java.util.List;

import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalRequest;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalResponse;

public interface IRegistroTerminalesService {
	
	public List<RegistroTerminalResponse> obtenerTerminales();
	
	public List<RegistroTerminalResponse> registrarTerminales(List<RegistroTerminalRequest> terminales, String username) throws PortalBackendException;

	public RegistroTerminalResponse actualizarTerminal(RegistroTerminalRequest terminal) throws PortalBackendException;

}
