package com.credibanco.migracion.portal.backend.models.dto;

import java.util.List;

import javax.validation.constraints.NotNull;

public class SolicitudTerminales {
	private String cantidadTerminales;
	private List<String> idTerminales;
	private String dueno;
	private String tipoDispositivo;
	private String tipoComunicacion;
	private String tipoIntegracionTEF;
	private String marcaDispositivo;
	private String indicadorIac;
	private String indicadorIva;
	@NotNull(message = "serviciosId es obligatorio")
	private List<String> idServicio;
	private Integer indicadorPropina;
	private String indicadorDeReferencia;
	private String indicadorCvv2;
	@NotNull(message = "direccionDeInstalacion es obligatorio")
	private DireccionInstalacion direccionDeInstalacion;
	private String estadoTerminal;
	private String razonEstado;
	private String serial;
	private String sello;
	private String numeroCaja;
	private String codigoArrendamiento;
	private String fechaRetiroProgramado;
	private String observaciones;
	public String getCantidadTerminales() {
		return cantidadTerminales;
	}
	public void setCantidadTerminales(String cantidadTerminales) {
		this.cantidadTerminales = cantidadTerminales;
	}
	public List<String> getIdTerminales() {
		return idTerminales;
	}
	public void setIdTerminales(List<String> idTerminales) {
		this.idTerminales = idTerminales;
	}
	public String getDueno() {
		return dueno;
	}
	public void setDueno(String dueno) {
		this.dueno = dueno;
	}
	public String getTipoDispositivo() {
		return tipoDispositivo;
	}
	public void setTipoDispositivo(String tipoDispositivo) {
		this.tipoDispositivo = tipoDispositivo;
	}
	public String getTipoComunicacion() {
		return tipoComunicacion;
	}
	public void setTipoComunicacion(String tipoComunicacion) {
		this.tipoComunicacion = tipoComunicacion;
	}
	public String getTipoIntegracionTEF() {
		return tipoIntegracionTEF;
	}
	public void setTipoIntegracionTEF(String tipoIntegracionTEF) {
		this.tipoIntegracionTEF = tipoIntegracionTEF;
	}
	public String getMarcaDispositivo() {
		return marcaDispositivo;
	}
	public void setMarcaDispositivo(String marcaDispositivo) {
		this.marcaDispositivo = marcaDispositivo;
	}
	public String getIndicadorIac() {
		return indicadorIac;
	}
	public void setIndicadorIac(String indicadorIac) {
		this.indicadorIac = indicadorIac;
	}
	public String getIndicadorIva() {
		return indicadorIva;
	}
	public void setIndicadorIva(String indicadorIva) {
		this.indicadorIva = indicadorIva;
	}
	public List<String> getIdServicio() {
		return idServicio;
	}
	public void setIdServicio(List<String> idServicio) {
		this.idServicio = idServicio;
	}
	public Integer getIndicadorPropina() {
		return indicadorPropina;
	}
	public void setIndicadorPropina(Integer indicadorPropina) {
		this.indicadorPropina = indicadorPropina;
	}
	public String getIndicadorDeReferencia() {
		return indicadorDeReferencia;
	}
	public void setIndicadorDeReferencia(String indicadorDeReferencia) {
		this.indicadorDeReferencia = indicadorDeReferencia;
	}
	public String getIndicadorCvv2() {
		return indicadorCvv2;
	}
	public void setIndicadorCvv2(String indicadorCvv2) {
		this.indicadorCvv2 = indicadorCvv2;
	}
	public DireccionInstalacion getDireccionDeInstalacion() {
		return direccionDeInstalacion;
	}
	public void setDireccionDeInstalacion(DireccionInstalacion direccionDeInstalacion) {
		this.direccionDeInstalacion = direccionDeInstalacion;
	}
	public String getEstadoTerminal() {
		return estadoTerminal;
	}
	public void setEstadoTerminal(String estadoTerminal) {
		this.estadoTerminal = estadoTerminal;
	}
	public String getRazonEstado() {
		return razonEstado;
	}
	public void setRazonEstado(String razonEstado) {
		this.razonEstado = razonEstado;
	}
	public String getSerial() {
		return serial;
	}
	public void setSerial(String serial) {
		this.serial = serial;
	}
	public String getSello() {
		return sello;
	}
	public void setSello(String sello) {
		this.sello = sello;
	}
	public String getNumeroCaja() {
		return numeroCaja;
	}
	public void setNumeroCaja(String numeroCaja) {
		this.numeroCaja = numeroCaja;
	}
	public String getCodigoArrendamiento() {
		return codigoArrendamiento;
	}
	public void setCodigoArrendamiento(String codigoArrendamiento) {
		this.codigoArrendamiento = codigoArrendamiento;
	}
	public String getFechaRetiroProgramado() {
		return fechaRetiroProgramado;
	}
	public void setFechaRetiroProgramado(String fechaRetiroProgramado) {
		this.fechaRetiroProgramado = fechaRetiroProgramado;
	}
	public String getObservaciones() {
		return observaciones;
	}
	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}
	@Override
	public String toString() {
		return "SolicitudTerminales [cantidadTerminales=" + cantidadTerminales + ", idTerminales=" + idTerminales
				+ ", dueno=" + dueno + ", tipoDispositivo=" + tipoDispositivo + ", tipoComunicacion=" + tipoComunicacion
				+ ", tipoIntegracionTEF=" + tipoIntegracionTEF + ", marcaDispositivo=" + marcaDispositivo
				+ ", indicadorIac=" + indicadorIac + ", indicadorIva=" + indicadorIva + ", idServicio=" + idServicio
				+ ", indicadorPropina=" + indicadorPropina + ", indicadorDeReferencia=" + indicadorDeReferencia
				+ ", indicadorCvv2=" + indicadorCvv2 + ", direccionDeInstalacion=" + direccionDeInstalacion
				+ ", estadoTerminal=" + estadoTerminal + ", razonEstado=" + razonEstado + ", serial=" + serial
				+ ", sello=" + sello + ", numeroCaja=" + numeroCaja + ", codigoArrendamiento=" + codigoArrendamiento
				+ ", fechaRetiroProgramado=" + fechaRetiroProgramado + ", observaciones=" + observaciones + "]";
	}

	
}
