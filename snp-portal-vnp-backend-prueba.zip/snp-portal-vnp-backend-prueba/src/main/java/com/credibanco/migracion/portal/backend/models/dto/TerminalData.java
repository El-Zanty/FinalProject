package com.credibanco.migracion.portal.backend.models.dto;

import java.util.ArrayList;

public class TerminalData {
	
	private String terminalId;
	private String uniqueCode;
	private String indicadorIca;
	private String indicadorIva;
	private String indicadorPropina;
	private String terminalState;
	private String indicadorReferencia;
	private ArrayList<String> servicios;
	
	public String getTerminalId() {
		return terminalId;
	}
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}
	public String getUniqueCode() {
		return uniqueCode;
	}
	public void setUniqueCode(String uniqueCode) {
		this.uniqueCode = uniqueCode;
	}
	public String getIndicadorIca() {
		return indicadorIca;
	}
	public void setIndicadorIca(String indicadorIca) {
		this.indicadorIca = indicadorIca;
	}
	public String getIndicadorIva() {
		return indicadorIva;
	}
	public void setIndicadorIva(String indicadorIva) {
		this.indicadorIva = indicadorIva;
	}
	public String getIndicadorPropina() {
		return indicadorPropina;
	}
	public void setIndicadorPropina(String indicadorPropina) {
		this.indicadorPropina = indicadorPropina;
	}
	public String getTerminalState() {
		return terminalState;
	}
	public void setTerminalState(String terminalState) {
		this.terminalState = terminalState;
	}
	public String getIndicadorReferencia() {
		return indicadorReferencia;
	}
	public void setIndicadorReferencia(String indicadorReferencia) {
		this.indicadorReferencia = indicadorReferencia;
	}	
	public ArrayList<String> getServicios() {
		return servicios;
	}
	public void setServicios(ArrayList<String> servicios) {
		this.servicios = servicios;
	}
	
	@Override
	public String toString() {
		return "TerminalData [terminalId=" + terminalId + ", uniqueCode=" + uniqueCode + ", indicadorIca="
				+ indicadorIca + ", indicadorIva=" + indicadorIva + ", indicadorPropina=" + indicadorPropina
				+ ", terminalState=" + terminalState + ", indicadorReferencia=" + indicadorReferencia + "]";
	}

}
