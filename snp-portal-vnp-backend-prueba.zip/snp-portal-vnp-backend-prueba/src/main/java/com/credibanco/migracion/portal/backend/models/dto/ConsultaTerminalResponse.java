package com.credibanco.migracion.portal.backend.models.dto;

public class ConsultaTerminalResponse {
	
	private String response;
	private String code;
	private String error;
	private String codBancoIndustria;
	
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getCodBancoIndustria() {
		return codBancoIndustria;
	}
	public void setCodBancoIndustria(String codBancoIndustria) {
		this.codBancoIndustria = codBancoIndustria;
	}
	@Override
	public String toString() {
		return "ConsultaTerminalResponse [response=" + response + ", code=" + code + ", error=" + error
				+ ", codBancoIndustria=" + codBancoIndustria + "]";
	}
	
}
