package com.credibanco.migracion.portal.backend.clients;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.credibanco.migracion.portal.backend.exceptions.ErrorDetails;
import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.SSOTokenDTO;
import com.credibanco.migracion.portal.backend.models.dto.SSOUserDTO;

@Component
//Cliente consumo API SSO
public class SSOAPIClient {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SSOAPIClient.class);
	
	@Value("${credibanco.client.sso.url}") //Apunta a pruebas sso
	private String ssoPasarelasUrl;
	
	@Value("${credibanco.client.sso.path}") //Posiblemente  está relacionado con el proceso de autenticación (Single Sign-On o SSO) de los clientes de Credibanco.
	private String ssoPasarelasPath;
	
	@Value("${credibanco.client.sso.usuarios.timeout}") // timepo de espera para relaizar la autenticacion 30s
	private Integer timeoutSSOGetUsers;
		
	@Value("${credibanco.client.sso.token.username}") //
	private String ssoPasarelasUsername;
	
	@Value("${credibanco.client.sso.token.password}")
	private String ssoPasarelasPassword;
	
	@Value("${credibanco.client.sso.token.client_id}")
	private String ssoPasarelasClientId;
	
	@Value("${credibanco.client.sso.token.timeout}")
	private Integer timeoutSSOToken;
	
	//Esta funcion obtiene el token que representa la sesion del usuario del SSO
	public SSOTokenDTO getTokenSession(String realmName) throws PortalBackendException {
		RestTemplate restTemplate = restTemplateWithTimeout(timeoutSSOToken);
		
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(ssoPasarelasUrl)
																.path(ssoPasarelasPath+"/realms/"+realmName+
																		"/protocol/openid-connect/token");
		
		String uri = uriBuilder.toUriString();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		
		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add("username", ssoPasarelasUsername);
		map.add("password", ssoPasarelasPassword);
		map.add("grant_type", "password");
		map.add("client_id", ssoPasarelasClientId);
		
		HttpEntity<?> entity = new HttpEntity<>(map, headers);
		ResponseEntity< SSOTokenDTO > result = null;
		
		try {
			LOGGER.info("getTokenSession(): Enviando solicitud, uri= " + uri );
			result = restTemplate.exchange(uri, HttpMethod.POST, entity, SSOTokenDTO.class);
			return result.getBody();
		}catch(HttpStatusCodeException e) {
			LOGGER.error("getTokenSession(): Error en la comunicacion el api del servico = "+ uri +", mensaje = " + e.getMessage());
			ErrorDetails emisorException = new ErrorDetails(new Date(), "99", "Error de comunicacion");
			throw new PortalBackendException(emisorException);
		}catch(RestClientException e) {
			LOGGER.error("getTokenSession(): Error en la comunicacion el api del servico = "+ uri +", mensaje = ", e.getMessage());
			ErrorDetails emisorException = new ErrorDetails(new Date(), "99", "Error de comunicacion");
			throw new PortalBackendException(emisorException);
		}catch(Exception e) {
			LOGGER.error("getTokenSession(): Error en la comunicacion el api del servico = "+ uri +", mensaje = ", e.getMessage());
			ErrorDetails emisorException = new ErrorDetails(new Date(), "99", "Error de comunicacion");
			throw new PortalBackendException(emisorException);
		}
	}

	//Esta funcion obtiene los usuarios del SSO filtrados por groupID y Realmname
	public List<SSOUserDTO> getUsersFromGroupAndRealm(String groupId, String realmName, String authToken) throws PortalBackendException {
		RestTemplate restTemplate = restTemplateWithTimeout(timeoutSSOGetUsers);
		
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(ssoPasarelasUrl)
																.path(ssoPasarelasPath+"/admin/realms/"
																		+realmName+"/groups/"+groupId+"/members");
		String uri = uriBuilder.toUriString();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setBearerAuth(authToken);
		
		HttpEntity<?> entity = new HttpEntity<>(null, headers);
		ResponseEntity< List<SSOUserDTO> > result = null;
		
		try {
			LOGGER.info("getUsersFromGroupAndRealm(): Enviando solicitud, uri= " + uri );
			result = restTemplate.exchange(uri, HttpMethod.GET, entity, new ParameterizedTypeReference<List<SSOUserDTO>>() {});
			return result.getBody();
		}catch(HttpStatusCodeException e) {
			LOGGER.error("getUsersFromGroupAndRealm(): Error en la comunicacion el api del servico = "+ uri +", mensaje = " + e.getMessage());
			ErrorDetails emisorException = new ErrorDetails(new Date(), "99", "Error de comunicacion");
			throw new PortalBackendException(emisorException);
		}catch(RestClientException e) {
			LOGGER.error("getUsersFromGroupAndRealm(): Error en la comunicacion el api del servico = "+ uri +", mensaje = ", e.getMessage());
			ErrorDetails emisorException = new ErrorDetails(new Date(), "99", "Error de comunicacion");
			throw new PortalBackendException(emisorException);
		}catch(Exception e) {
			LOGGER.error("getUsersFromGroupAndRealm(): Error en la comunicacion el api del servico = "+ uri +", mensaje = ", e.getMessage());
			ErrorDetails emisorException = new ErrorDetails(new Date(), "99", "Error de comunicacion");
			throw new PortalBackendException(emisorException);
		}
	}
	
	private RestTemplate restTemplateWithTimeout(int timeout){
		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
		= new HttpComponentsClientHttpRequestFactory();
		clientHttpRequestFactory.setConnectTimeout(timeout);
		clientHttpRequestFactory.setConnectionRequestTimeout(timeout);
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
		return restTemplate;
	}

}
