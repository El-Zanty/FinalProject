package com.credibanco.migracion.portal.backend.utils;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;

public class MapperUtils {

    private static ModelMapper modelMapper = new ModelMapper();
    
    private MapperUtils() {}

    public static <S, T> List<T> mapList(List<S> source, Class<T> targetClass) {
        return source
                .stream()
                .map(element -> modelMapper.map(element, targetClass))
                .collect(Collectors.toList());
    }
    
    public static <T> T mapObject(Object object, Class<T> targetClass){
    	return modelMapper.map(object, targetClass);
    }
}
