package com.credibanco.migracion.portal.backend.models.dto;

public class AirlineDto {
	
	private Integer id;
	
	private String name;
	
	private boolean nacional;
	
	private Integer uniqueCode;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isNacional() {
		return nacional;
	}
	public void setNacional(boolean nacional) {
		this.nacional = nacional;
	}
	public Integer getUniqueCode() {
		return uniqueCode;
	}
	public void setUniqueCode(Integer uniqueCode) {
		this.uniqueCode = uniqueCode;
	}
	@Override
	public String toString() {
		return "AirlineDto [id=" + id + ", name=" + name + ", nacional=" + nacional + ", uniqueCode=" + uniqueCode
				+ "]";
	}
	
	
}
