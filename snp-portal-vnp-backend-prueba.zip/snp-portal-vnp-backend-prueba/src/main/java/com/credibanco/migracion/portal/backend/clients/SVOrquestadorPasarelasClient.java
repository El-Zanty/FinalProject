package com.credibanco.migracion.portal.backend.clients;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.exceptions.TransactionException;
import com.credibanco.migracion.portal.backend.models.dto.OrquestadorPasarelasCreateRequestDTO;
import com.credibanco.migracion.portal.backend.models.dto.OrquestadorPasarelasDTO;
import com.credibanco.migracion.portal.backend.models.dto.OrquestadorPasarelasInactivarResponseDTO;
import com.credibanco.migracion.portal.backend.models.dto.OrquestadorPasarelasModificarRequestDTO;
import com.credibanco.migracion.portal.backend.models.dto.OrquestadorPasarelasModificarResponseDTO;
import com.credibanco.migracion.portal.backend.models.dto.PasarelaDTO;
import com.credibanco.migracion.portal.backend.services.PasarelasServiceImpl;

@Component
@PropertySource("classpath:application.properties")
public class SVOrquestadorPasarelasClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(SVOrquestadorPasarelasClient.class);

    @Value("${credibanco.client.svOrquestadorPasarelas.url}")
    private String svOrquestadorPasarelasUrl;

    @Value("${credibanco.client.svOrquestadorPasarelas.consulta.timeout}")
    private int svOrquestadorPasarelaConsultaTimeout;

    @Value("${credibanco.client.svOrquestadorPasarelas.consulta.path}")
    private String svOrquestadorPasarelasConsultaPath;

    @Value("${credibanco.client.svOrquestadorPasarelas.comercios}")
    private String svOrquestadorPasarelasComercio;

    @Value("${credibanco.client.svOrquestadorPasarelas.pasarelas}")
    private String svOrquestadorPasarelas;

    @Value("${credibanco.client.svOrquestadorPasarelas.usuarios}")
    private String svOrquestadorPasarelasUsuario;
    
    @Value("${credibanco.client.sso.token.username}")
    private String ssoUserName;
    
    @Value("${credibanco.client.sso.token.password}")
    private String ssoPassword;

    private PasarelasServiceImpl pasarelasService;

    public SVOrquestadorPasarelasClient(PasarelasServiceImpl pasarelasService) {
        this.pasarelasService = pasarelasService;
    }

    public OrquestadorPasarelasDTO postCrearTerminal(OrquestadorPasarelasCreateRequestDTO orquestadorPasarelasCreateRequestDTO, String usuario){

        RestTemplate restTemplate = restTemplateWithTimeout(svOrquestadorPasarelaConsultaTimeout);

        UriComponentsBuilder uriBuilder =
                UriComponentsBuilder.fromHttpUrl(svOrquestadorPasarelasUrl)
                        .path(svOrquestadorPasarelasConsultaPath);
        String uri = uriBuilder.toUriString();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBasicAuth(ssoUserName, ssoPassword);
        
        orquestadorPasarelasCreateRequestDTO.setUsuario(usuario);
              
		
        HttpEntity<OrquestadorPasarelasCreateRequestDTO> entity = new HttpEntity<>(orquestadorPasarelasCreateRequestDTO, headers);

        ResponseEntity<OrquestadorPasarelasDTO> result = null;

        try {
            if(!pasarelaValida(orquestadorPasarelasCreateRequestDTO.getPasarela())) {
             throw new Exception("Pasarela invalida");
            }
            LOGGER.info(String.format("getTransaction(): Enviando solicitud WS Transacciones, url = %s ", uri));
            result = restTemplate.exchange(uri, HttpMethod.POST, entity, OrquestadorPasarelasDTO.class);
            return result.getBody();
        }catch(HttpStatusCodeException e) {
            LOGGER.error("getTransaction(): Error en el WS, url = "+ uri +", mensaje = "+ e.getResponseBodyAsString());
            throw new TransactionException("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getResponseBodyAsString());
        }catch(RestClientException e) {
            LOGGER.error("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
            throw new TransactionException(e.getMessage());
        }catch(Exception e) {
            LOGGER.error("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
            throw new TransactionException(e.getMessage());
        }
    }

    public OrquestadorPasarelasModificarResponseDTO putModificarterminal(OrquestadorPasarelasModificarRequestDTO orquestadorPasarelasModificarRequestDTO, String usuario){

        RestTemplate restTemplate = restTemplateWithTimeout(svOrquestadorPasarelaConsultaTimeout);

        UriComponentsBuilder uriBuilder =
                UriComponentsBuilder.fromHttpUrl(svOrquestadorPasarelasUrl)
                        .path(svOrquestadorPasarelasConsultaPath);
        String uri = uriBuilder.toUriString();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBasicAuth(ssoUserName, ssoPassword);

        orquestadorPasarelasModificarRequestDTO.setUsuario(usuario);
        HttpEntity<OrquestadorPasarelasModificarRequestDTO> entity = new HttpEntity<>(orquestadorPasarelasModificarRequestDTO, headers);

        ResponseEntity<OrquestadorPasarelasModificarResponseDTO> result = null;

        try {
            if(!pasarelaValida(orquestadorPasarelasModificarRequestDTO.getPasarela())) {
                throw new Exception("Pasarela invalida");
            }
            LOGGER.info(String.format("getTransaction(): Enviando solicitud WS Transacciones, url = %s ", uri));
            result = restTemplate.exchange(uri, HttpMethod.PUT, entity, OrquestadorPasarelasModificarResponseDTO.class);
            return result.getBody();
        }catch(HttpStatusCodeException e) {
            LOGGER.error("getTransaction(): Error en el WS, url = "+ uri +", mensaje = "+ e.getResponseBodyAsString());
            throw new TransactionException("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getResponseBodyAsString());
        }catch(RestClientException e) {
            LOGGER.error("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
            throw new TransactionException(e.getMessage());
        }catch(Exception e) {
            LOGGER.error("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
            throw new TransactionException(e.getMessage());
        }
    }

    public OrquestadorPasarelasInactivarResponseDTO deleteterminal (String comercio, String terminal, String pasarela, String usuario){

        RestTemplate restTemplate = restTemplateWithTimeout(svOrquestadorPasarelaConsultaTimeout);

        UriComponentsBuilder uriBuilder =
                UriComponentsBuilder.fromHttpUrl(svOrquestadorPasarelasUrl)
                        .path(svOrquestadorPasarelasConsultaPath + "/" + terminal + svOrquestadorPasarelasComercio + "/" + comercio + svOrquestadorPasarelas + "/" + pasarela + svOrquestadorPasarelasUsuario + "/" + usuario);
        String uri = uriBuilder.toUriString();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBasicAuth(ssoUserName, ssoPassword);
        HttpEntity<?> entity = new HttpEntity<>(null, headers);

        ResponseEntity<OrquestadorPasarelasInactivarResponseDTO> result = null;

        try {
            if(!pasarelaValida(pasarela)) {
                throw new Exception("Pasarela invalida");
            }
            LOGGER.info(String.format("getTransaction(): Enviando solicitud WS Transacciones, url = %s ", uri));
            result = restTemplate.exchange(uri, HttpMethod.DELETE, entity, OrquestadorPasarelasInactivarResponseDTO.class);
            return result.getBody();
        }catch(HttpStatusCodeException e) {
            LOGGER.error("getTransaction(): Error en el WS, url = "+ uri +", mensaje = "+ e.getResponseBodyAsString());
            throw new TransactionException("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getResponseBodyAsString());
        }catch(RestClientException e) {
            LOGGER.error("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
            throw new TransactionException(e.getMessage());
        }catch(Exception e) {
            LOGGER.error("getTransaction(): Error en la comunicacion con el WS, url = "+ uri +", mensaje = "+ e.getMessage());
            throw new TransactionException(e.getMessage());
        }
    }

    private RestTemplate restTemplateWithTimeout(int timeout) {
        HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
                = new HttpComponentsClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(timeout);
        return new RestTemplate(clientHttpRequestFactory);
    }

    private Boolean pasarelaValida(String pasarela) throws PortalBackendException {
        List<PasarelaDTO> listaPasarelas = pasarelasService.getPasarelas();
        return listaPasarelas.stream().map(PasarelaDTO::getUsuario).filter(pasarela::equals).findFirst().isPresent();
    }
}

