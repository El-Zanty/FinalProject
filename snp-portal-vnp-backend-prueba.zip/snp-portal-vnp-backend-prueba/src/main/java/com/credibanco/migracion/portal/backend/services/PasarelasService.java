package com.credibanco.migracion.portal.backend.services;

import java.util.List;

import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.PasarelaDTO;

public interface PasarelasService {

	List<PasarelaDTO> getPasarelas() throws PortalBackendException;

}
