package com.credibanco.migracion.portal.backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.credibanco.migracion.portal.backend.models.entity.Airline;
import com.credibanco.migracion.portal.backend.models.repository.AirlineDao;

@Service
public class AirlineServiceImpl implements IAirlineService{
	
	@Autowired
	private AirlineDao airlineRepository;

	@Override
	public  Airline findAirlineById(Integer id) {
		return airlineRepository.findById(id).orElse(null);
	}

	@Override
	@Transactional
	public Airline modificarAerolinea(Airline airline) {
		return airlineRepository.save(airline);	
	}

	@Override
	public List<Airline> findAll() {
		return (List<Airline>) airlineRepository.findAll();
	}

}
