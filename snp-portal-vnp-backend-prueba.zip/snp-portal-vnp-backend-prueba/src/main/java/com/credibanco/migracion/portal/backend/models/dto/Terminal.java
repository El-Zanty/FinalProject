package com.credibanco.migracion.portal.backend.models.dto;

import java.util.List;

public class Terminal {
	private String tipoServicio;
	private String usuarioOriginador;
	private String codigoComercio;
	private List<SolicitudTerminales> solicitudTerminales;
	public String getTipoServicio() {
		return tipoServicio;
	}
	public void setTipoServicio(String tipoServicio) {
		this.tipoServicio = tipoServicio;
	}
	public String getUsuarioOriginador() {
		return usuarioOriginador;
	}
	public void setUsuarioOriginador(String usuarioOriginador) {
		this.usuarioOriginador = usuarioOriginador;
	}
	public String getCodigoComercio() {
		return codigoComercio;
	}
	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public List<SolicitudTerminales> getSolicitudTerminales() {
		return solicitudTerminales;
	}
	public void setSolicitudTerminales(List<SolicitudTerminales> solicitudTerminales) {
		this.solicitudTerminales = solicitudTerminales;
	}
	@Override
	public String toString() {
		return "Terminal [tipoServicio=" + tipoServicio + ", usuarioOriginador=" + usuarioOriginador
				+ ", codigoComercio=" + codigoComercio + ", solicitudTerminales=" + solicitudTerminales + "]";
	}

}
