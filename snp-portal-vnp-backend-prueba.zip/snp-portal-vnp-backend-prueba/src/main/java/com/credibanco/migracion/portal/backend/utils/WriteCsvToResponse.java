package com.credibanco.migracion.portal.backend.utils;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.credibanco.migracion.portal.backend.models.dto.CSVTerminalesColumns;
import com.credibanco.migracion.portal.backend.models.dto.RegistroTerminalResponse;
import com.credibanco.migracion.transacciones.dto.TransactionUnrestricted;
import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvException;

public class WriteCsvToResponse {
	
	private static final Logger LOG = LoggerFactory.getLogger(WriteCsvToResponse.class);
	
	public static void writeTransacions(PrintWriter writer, List<TransactionUnrestricted> transactions) {
	    transactions.forEach( element -> {
	        element.setTransactionObjectRequest(element.getTransactionObjectRequest().replace("," , " - "));
        });
        try {
            StatefulBeanToCsv<TransactionUnrestricted> btcsv = new StatefulBeanToCsvBuilder<TransactionUnrestricted>(writer)
            		.withQuotechar(CSVWriter.NO_QUOTE_CHARACTER)
            		.withSeparator(',')
                    .build();
            btcsv.write(transactions);
        } catch (CsvException ex) {
            LOG.error("Error mapping Bean to CSV", ex);
        }
	}
	
    public static void writeTerminales(PrintWriter writer, List<CSVTerminalesColumns> terminales) {
	
        try {
        	writer.append(buildHeader(CSVTerminalesColumns.class));
            StatefulBeanToCsv<CSVTerminalesColumns> btcsv = new StatefulBeanToCsvBuilder<CSVTerminalesColumns>(writer)
                    .withQuotechar(CSVWriter.NO_QUOTE_CHARACTER)
                    .withSeparator(',')
                    .build();
            
            btcsv.write(terminales);
            writer.close();

        } catch (CsvException ex) {

            LOG.error("Error mapping Bean to CSV", ex);
        }
		
	}
    
    private static String buildHeader(Class<CSVTerminalesColumns> clazz) {
        return Arrays.stream( clazz.getDeclaredFields() )
                .filter( f -> f.getAnnotation( CsvBindByPosition.class ) != null
                        && f.getAnnotation( CsvBindByName.class ) != null )
                .sorted( Comparator.comparing( f -> f.getAnnotation( CsvBindByPosition.class ).position() ) )
                .map( f -> f.getAnnotation( CsvBindByName.class ).column() )
                .collect( Collectors.joining( "," ) ) + "\n";
    }
    
    public static void writeResponseTerminales(PrintWriter writer, List<RegistroTerminalResponse> list) {
        try {
        	writer.append(buildHeaderResponse(RegistroTerminalResponse.class));
            StatefulBeanToCsv<RegistroTerminalResponse> btcsv = new StatefulBeanToCsvBuilder<RegistroTerminalResponse>(writer)
                    .withQuotechar(CSVWriter.NO_QUOTE_CHARACTER)
                    .withSeparator(',')
                    .build();
            
            btcsv.write(list);
            writer.close();

        } catch (CsvException ex) {

            LOG.error("Error mapping Bean to CSV", ex);
        }
		
	}
    
    private static String buildHeaderResponse(Class<RegistroTerminalResponse> clazz) {
        return Arrays.stream( clazz.getDeclaredFields() )
                .filter( f -> f.getAnnotation( CsvBindByPosition.class ) != null
                        && f.getAnnotation( CsvBindByName.class ) != null )
                .sorted( Comparator.comparing( f -> f.getAnnotation( CsvBindByPosition.class ).position() ) )
                .map( f -> f.getAnnotation( CsvBindByName.class ).column() )
                .collect( Collectors.joining( "," ) ) + "\n";
    }

}
