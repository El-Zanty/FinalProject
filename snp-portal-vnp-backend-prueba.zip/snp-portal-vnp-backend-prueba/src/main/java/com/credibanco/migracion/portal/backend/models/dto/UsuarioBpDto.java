package com.credibanco.migracion.portal.backend.models.dto;

public class UsuarioBpDto {

	private String username;
	private String enabled;
	private String uniqueCode;
	private String terminalId;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEnabled() {
		return enabled;
	}
	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}
	public String getUniqueCode() {
		return uniqueCode;
	}
	public void setUniqueCode(String uniqueCode) {
		this.uniqueCode = uniqueCode;
	}
	public String getTerminalId() {
		return terminalId;
	}
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}
	@Override
	public String toString() {
		return "UsuarioBpDto [username=" + username + ", enabled=" + enabled + ", uniqueCode=" + uniqueCode
				+ ", terminalId=" + terminalId + "]";
	}
	
	
	
}
