package com.credibanco.migracion.portal.backend.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;


@ControllerAdvice
public class GlobalExceptionHandler{
	
	// handle specific exceptions
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<Object> handleResourceNotFoundException
	(ResourceNotFoundException exception, WebRequest request){
		ErrorDetails errorDetails = new ErrorDetails(new Date(), "Resource not found", exception.getMessage());
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}
	
	
	// Handle Global exception
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> handleGlobalException
	(Exception exception, WebRequest request){
		ErrorDetails errorDetails = new ErrorDetails(new Date(), "Internal error",  exception.getLocalizedMessage());
		return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	// handler not valid exception
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Object> customValidationErrorHandling(MethodArgumentNotValidException exception, WebRequest request){
		String exceptionMessage = exception.getBindingResult().getFieldError().getDefaultMessage();
		ErrorDetails errorDetails = new ErrorDetails(new Date(),"Validation error", exceptionMessage);
		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}
	
	// handler format error exception
	@ExceptionHandler(TransactionException.class)
	public ResponseEntity<Object> handleTransactionException(TransactionException exception, WebRequest request){		
		ErrorDetails errorDetails = new ErrorDetails(new Date(),"Transaction error", exception.getMessage());
		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(PortalBackendException.class)
	public ResponseEntity<Object> handlePortalBackendException(PortalBackendException exception, WebRequest request){		
		ErrorDetails errorDetails = new ErrorDetails(new Date(),exception.getError().getMessage(), exception.getError().getDetails());
		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}
	
}
