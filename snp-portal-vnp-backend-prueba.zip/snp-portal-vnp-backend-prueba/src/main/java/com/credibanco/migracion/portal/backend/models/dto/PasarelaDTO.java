package com.credibanco.migracion.portal.backend.models.dto;

public class PasarelaDTO {
	private String fechaCreacion;
	private String usuario;
	private String correoElectronico;
	private Boolean activo;
	
	public PasarelaDTO() {
		super();
	}

	public PasarelaDTO(String fechaCreacion, String usuario, String correoElectronico, Boolean activo) {
		super();
		this.fechaCreacion = fechaCreacion;
		this.usuario = usuario;
		this.correoElectronico = correoElectronico;
		this.activo = activo;
	}

	public String getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getCorreoElectronico() {
		return correoElectronico;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	@Override
	public String toString() {
		return "PasarelaDTO [fechaCreacion=" + fechaCreacion + ", usuario=" + usuario + ", correoElectronico="
				+ correoElectronico + ", activo=" + activo + "]";
	}
	
}
