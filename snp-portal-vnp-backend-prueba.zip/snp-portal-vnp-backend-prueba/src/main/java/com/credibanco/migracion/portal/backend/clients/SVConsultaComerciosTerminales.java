package com.credibanco.migracion.portal.backend.clients;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.credibanco.migracion.portal.backend.exceptions.ErrorDetails;
import com.credibanco.migracion.portal.backend.exceptions.PortalBackendException;
import com.credibanco.migracion.portal.backend.models.dto.ConsultaTerminalRequest;
import com.credibanco.migracion.portal.backend.models.dto.ConsultaTerminalResponse;

@Component
public class SVConsultaComerciosTerminales {

	private static final Logger LOGGER = LoggerFactory.getLogger(SVTerminalGenericaClient.class);
	
	@Value("${credibanco.client.sv-consulta-comercios-terminales.uri}")
	private String uriConsultaTerminal;
	
	@Value("${credibanco.client.sv-consulta-comercios-terminales.path}")
	private String pathConsultaTerminal;
	
	@Value("${credibanco.client.sv-consulta-comercios-terminales.timeout}")
	private Integer timeoutConsultaTerminal;
	
	@Value("${credibanco.client.sv-consulta-comercios-terminales.auth.basic.base64}")
	private String base64Credentials;

	public ConsultaTerminalResponse consultaUnicaTerminal(ConsultaTerminalRequest consultaTerminalRequest) throws PortalBackendException {
		
		RestTemplate restTemplate = restTemplateWithTimeout(timeoutConsultaTerminal);
		
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(uriConsultaTerminal)
																.path(pathConsultaTerminal);
		
		String uri = uriBuilder.toUriString();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("Authorization", "Basic "+base64Credentials);
		
		HttpEntity<ConsultaTerminalRequest> entity = new HttpEntity<>(consultaTerminalRequest, headers);
		ResponseEntity<ConsultaTerminalResponse> result = null;
		
		try {
			LOGGER.info("postTerminalGenerica(): Enviando solicitud, uri= " + uri + ",with params: " + consultaTerminalRequest);
			result = restTemplate.exchange(uri, HttpMethod.POST, entity, ConsultaTerminalResponse.class);
			return result.getBody();
		}catch(HttpStatusCodeException e) {
			LOGGER.error("postTerminalGenerica(): Error en la comunicacion el api del servico = "+ uri +", mensaje = " + e.getMessage());
			ErrorDetails emisorException = new ErrorDetails(new Date(), "99", "Error de comunicacion");
			throw new PortalBackendException(emisorException);
		}catch(RestClientException e) {
			LOGGER.error("postTerminalGenerica(): Error en la comunicacion el api del servico = "+ uri +", mensaje = ", e.getMessage());
			ErrorDetails emisorException = new ErrorDetails(new Date(), "99", "Error de comunicacion");
			throw new PortalBackendException(emisorException);
		}catch(Exception e) {
			LOGGER.error("postTerminalGenerica(): Error en la comunicacion el api del servico = "+ uri +", mensaje = ", e.getMessage());
			ErrorDetails emisorException = new ErrorDetails(new Date(), "99", "Error de comunicacion");
			throw new PortalBackendException(emisorException);
		}
	}
	
	private RestTemplate restTemplateWithTimeout(int timeout){
		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
		= new HttpComponentsClientHttpRequestFactory();
		clientHttpRequestFactory.setConnectTimeout(timeout);
		clientHttpRequestFactory.setConnectionRequestTimeout(timeout);
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
		return restTemplate;
	}
}
