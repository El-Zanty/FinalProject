package com.credibanco.migracion.portal.backend.domain.models;

public class AirLine {

    private Integer id;
    private String name;
    private Integer nacional;
    private String uniqueCode;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getNacional() {
        return nacional;
    }

    public void setNacional(Integer nacional) {
        this.nacional = nacional;
    }

    public String getUniqueCode() {
        return uniqueCode;
    }

    public void setUniqueCode(String uniqueCode) {
        this.uniqueCode = uniqueCode;
    }

    @Override
    public String toString() {
        return "AirLine{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", nacional=" + nacional +
                ", uniqueCode='" + uniqueCode + '\'' +
                '}';
    }

    public AirLine(Integer id, String name, Integer nacional, String uniqueCode) {
        this.id = id;
        this.name = name;
        this.nacional = nacional;
        this.uniqueCode = uniqueCode;
    }

    public AirLine() {
    }
}
