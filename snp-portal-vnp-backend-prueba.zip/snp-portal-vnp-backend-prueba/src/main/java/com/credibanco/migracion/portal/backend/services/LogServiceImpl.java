package com.credibanco.migracion.portal.backend.services;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.credibanco.migracion.transacciones.dto.Log;


@Service
public class LogServiceImpl implements ILogService{
	
	@Autowired
	private ITransactionService servicioTransacciones;

	@Override
	@Transactional
	public void saveLog(Log log) {
		servicioTransacciones.postLog(log);
	}

	@Override
	public Log construirObjetoLog(String usuario, String objeto, String accion, String ip, String despues,
			String antes) {
		Log log = new Log();
		log.setUsuario(usuario);
		log.setObjeto(objeto);
		log.setAccion(accion);
		log.setIp(ip);
		log.setDespues(despues);
		log.setAntes(antes);
		log.setFecha(new Date());
		return log;
	}

}
